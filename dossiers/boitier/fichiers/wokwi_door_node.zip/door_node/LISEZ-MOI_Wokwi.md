# Simuler la carte de porte dans Wokwi

Wokwi (wokwi.com) simule un ESP32 dans le navigateur, gratuitement. Ce projet fait tourner le firmware **door_node** (système Wi-Fi) et montre ce que font les relais K1 (ouverture) et K2 (fermeture commandée). Il vérifie la **logique** du firmware, pas le câblage 24 V de la porte.

## Mise en route (5 minutes)

1. Ouvrir https://wokwi.com/projects/new/esp32 (nouveau projet ESP32, Arduino).
2. Onglet **sketch.ino** : tout effacer, coller le contenu de `sketch.ino`.
3. Onglet **diagram.json** : tout effacer, coller le contenu de `diagram.json`.
4. Cliquer sur le bouton vert **Démarrer** (▶). Le moniteur série s'ouvre en bas.
5. Optionnel : **Save** (compte Wokwi gratuit) pour garder le projet.

## Ce qu'on voit sur le schéma

| Pièce | Rôle |
|---|---|
| ESP32 | la carte ESP32-RELAY02 (même processeur, mêmes broches 16 et 17) |
| Relais `k1_ouverture` (GPIO16) | K1, le contact câblé en parallèle du bouton vert |
| LED verte « K1 ouverture » | s'allume quand le contact de K1 est fermé = « appui sur le bouton vert » |
| Relais `k2_fermeture` (GPIO17) + LED rouge « K2 fermeture » | K2, le contact câblé en parallèle du bouton de fermeture (portes qui ne se referment pas seules). Ne s'allume **jamais** tant que `close` vaut 0 |
| LED bleue « GPIO16 » | témoin direct de la commande envoyée à K1 |

## Essais à faire (taper les commandes dans le moniteur série, puis Entrée)

| Commande | Ce qu'on doit observer |
|---|---|
| (démarrage) | Le moniteur affiche `door_node 2.1.0-auto`, la configuration, puis `Configuration incomplete`. **Toutes les LED sont éteintes** : relais au repos dès le démarrage. |
| `help` | La liste des commandes. |
| `test_pulse` | `test_pulse : OK (pulsed)`. Les LED bleue et verte s'allument **une seule fois, 0,5 s**. La rouge reste éteinte. |
| `test_pulse` deux fois de suite | La 2ᵉ répond `refuse (cooldown)` : pas de 2ᵉ impulsion avant 3 s. |
| `set door_id P01` | `enregistre.` |
| `set ssid Wokwi-GUEST` | `enregistre.` (réseau Wi-Fi ouvert de Wokwi, sans mot de passe : ne pas taper `set wifi_pass`) |
| `set token demo-wokwi-0123456789` | `enregistre.` (jeton de démonstration, 16 caractères minimum ; `set token court` est refusé) |
| `set pulse_ms 5000` | `enregistre.` : on tente une impulsion trop longue… |
| `reboot` | La carte redémarre **sans aucune impulsion** (LED éteintes), affiche la configuration puis `Serveur HTTP demarre`. |
| `show` | `pulse_ms : 2000` : la durée est **bornée à 2 s** quoi qu'on configure. `wifi : connecte ip=…` après quelques secondes. |
| `set pulse_ms 500` puis `reboot` | Retour au réglage normal. |
| `test_close` | Avec le réglage par défaut (`close : 0`, porte qui se referme seule) : `test_close : refuse, fermeture commandee desactivee`. La LED rouge reste éteinte. |
| `set close 1` puis `reboot` | `show` affiche `close : 1 (fermeture commandee, K2 actif)`. |
| `test_close` | `test_close : OK (pulsed)`. La LED **rouge « K2 fermeture »** s'allume **une seule fois, 0,5 s** ; la verte et la bleue restent éteintes. |
| `test_pulse` puis tout de suite `test_close` | La fermeture est refusée (`pulse_in_progress` pendant l'impulsion, puis `too_soon_after_open` pendant 2 s) : jamais K1 et K2 ensemble, jamais une fermeture juste après une ouverture. |
| `set close 0` puis `reboot` | Retour au réglage d'une porte qui se referme seule. |

Si `show` après `reboot` affiche une configuration vide, c'est que la mémoire de la carte simulée n'a pas été conservée au redémarrage : retaper les commandes `set`. En principe, la configuration repart à zéro à chaque nouveau démarrage de la simulation (bouton ■ puis ▶) : retaper les commandes `set`.

**Contrôle du relais simulé** : au démarrage, la LED verte doit être éteinte. Si elle est allumée alors que la LED bleue est éteinte, la logique du relais Wokwi est inversée : dans `diagram.json`, remplacer `"transistor": "pnp"` par `"transistor": "npn"` sur les deux relais. Même contrôle pour la LED rouge et K2. (La documentation Wokwi se contredit sur ce point : elle annonce « npn = actif à l'état haut » mais décrit le contraire.)

## Ce que Wokwi ne permet pas de tester

- **Le Bluetooth** : Wokwi ne simule pas le Bluetooth de l'ESP32 (tableau des fonctions de la doc Wokwi). Le firmware Bluetooth (door_ble) et le pont ne se testent pas ici.
- **Les ordres HTTP envoyés depuis le PC** (`/api/v1/open` avec le jeton) : la carte simulée se connecte bien au Wi-Fi, mais recevoir des connexions depuis le PC demande la « Private IoT Gateway » de Wokwi, **réservée aux abonnés payants**. Sans elle, l'API n'est pas joignable.
- **Le câblage réel** : 24 V AC, redresseur, bornier de l'armoire. Ce n'est pas simulé (voir la simulation électrique du redresseur).

Pour tester l'API sans carte : le simulateur `tools/door_simulator.py` du dossier `spot_doors_v2` reproduit les mêmes requêtes (`health`, `status`, `open`, `close`, jeton, anti-rebond, verrous) sur le PC ; `--close-mode commande` simule une porte qui ne se referme pas seule :

```
export SPOT_DOOR_TOKEN=demo-wokwi-0123456789
python3 tools/door_simulator.py --door-id P01 --port 8081
python3 -m spot_doors.cli status --config doors.yaml --door P01
# porte à fermeture commandée :
python3 tools/door_simulator.py --door-id P06 --port 8086 --close-mode commande --close-time 6
```

Puis l'essai final se fait sur la vraie carte, sur table (voir le dossier de chantier Wi-Fi, « Tester sur table »).

## Différence avec le firmware réel

`sketch.ino` est une copie de `firmware/door_node/door_node.ino`. Seule adaptation, repérée par `// WOKWI:` : l'initialisation du chien de garde s'écrit pour les deux versions du cœur Arduino-ESP32 (2.x et 3.x), parce que la version utilisée par wokwi.com n'est pas publiée. Le comportement est le même.

Sources : documentation Wokwi, guide ESP32 (fonctions simulées, Bluetooth non simulé) https://docs.wokwi.com/guides/esp32 ; guide Wi-Fi (réseau Wokwi-GUEST, passerelle privée payante) https://docs.wokwi.com/guides/esp32-wifi ; module relais https://docs.wokwi.com/parts/wokwi-relay-module ; format diagram.json https://docs.wokwi.com/diagram-format.
