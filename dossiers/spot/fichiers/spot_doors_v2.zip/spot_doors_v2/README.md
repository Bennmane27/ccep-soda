# spot_doors v2 — Spot ouvre les portes automatiques (mode auto)

Version 2.0.0 — 19 octobre 2026. Remplace la chaîne espagnole (I2C + Bluetooth) pour vos portes,
qui fonctionnent **toujours en mode automatique** : une impulsion sur « Ouverture » déclenche la
montée complète puis la fermeture temporisée par l'automatisme de la porte.

## Architecture en trois couches

| Couche | Où | Rôle | Contenu |
|---|---|---|---|
| 1. Porte | ESP32-RELAY02 dans un coffret, à chaque porte | Fermer K1 pendant 500 ms en parallèle du bouton vert | `firmware/door_node` |
| 2. Spot natif | Logiciel du robot (≥ 5.1) | Appeler le module par le réseau depuis une action de mission | `config/spot_native_access_control.json` |
| 3. Plateforme | CORE I/O (Extension Spot) | Vérifier le passage avec les caméras, temps, journal ; héberger les futures applications | `spot_doors/`, `extension/` |

La couche 1 est obligatoire dans tous les cas : sans relais, rien n'appuie sur le bouton.
Les couches 2 et 3 sont deux façons de la commander :

- **Mode natif (sans CORE I/O)** : le plus simple. À tester en premier pour valider la porte et le réseau.
  Limite : la confirmation du passage dépend de ce que fait la fonction native, à vérifier sur votre robot.
- **Mode plateforme (CORE I/O)** : Spot ne repart que si les caméras confirment un passage libre
  et s'il reste le temps de passer avant la fermeture. C'est le mode visé pour l'autonomie complète.

## Contenu

```
firmware/door_node/door_node.ino   firmware de la carte de porte (Wi-Fi, API HTTP, jeton)
firmware/host_test/                test du firmware sur PC (g++), sans carte
spot_doors/                        service Python (Area Callback "porte-auto", vision, journal)
tools/door_simulator.py            faux module de porte + porte simulée pour les essais
config/                            exemples : portes, secrets, configuration native Spot
extension/                         paquet Spot Extension pour le CORE I/O (.spx)
tests/                             35 tests (logique, vision, réseau, fermeture commandée, utilitaire Boston Dynamics)
```

## Démarrage rapide (PC)

```bash
pip install -r requirements.txt
python3 -m pytest -q tests                      # 35 tests
g++ -std=gnu++17 -I firmware/host_test -o t firmware/host_test/test_door_node.cpp && ./t

export SPOT_DOOR_TOKEN=$(python3 -c "import secrets; print(secrets.token_urlsafe(24))")
python3 tools/door_simulator.py --door-id P01 --port 8081 &
# doors.yaml : host 127.0.0.1, port 8081
python3 -m spot_doors.cli status --config doors.yaml --door P01
```

## Programmer une carte de porte

1. Arduino IDE, carte « ESP32 Dev Module » (core esp32 by Espressif 3.x). Adaptateur USB-série
   **3,3 V**, RX/TX croisés, cavalier IO0-GND pour le chargement.
2. Téléverser `door_node.ino`, ouvrir le moniteur série à 115200 bauds, taper :
   ```
   set door_id P01
   set ssid <réseau fourni par l'informatique>
   set wifi_pass <mot de passe>
   set token <jeton du site>
   reboot
   ```
3. Sur banc : `test_pulse` doit faire coller K1 une seule fois, 500 ms. Le relais doit rester
   relâché au démarrage et après un reset.

## Mode natif Spot (≥ 5.1)

`config/spot_native_access_control.json` décrit les appels OPEN/CLOSE au format de l'utilitaire
Boston Dynamics `access_controlled_door_util` (vérifié par un test automatique). Le **DoorID**
enregistré dans la mission est l'adresse du module (ex. `10.0.0.41`). CLOSE envoie l'impulsion K2
sur une porte à fermeture commandée ; sur une porte qui se referme seule, le module la refuse
(409) : utiliser alors `spot_native_access_control_portes_auto.json` (OPEN seulement). L'endroit où charger cette configuration sur le robot (console
d'administration ou Orbit) est à confirmer sur votre version.

## Mode plateforme (CORE I/O)

1. `extension/build_extension.sh` → `spot_doors.spx`, à installer depuis l'interface du CORE I/O.
2. Sur le CORE I/O, renseigner `doors.yaml` et `secrets.env` dans le dossier de l'Extension.
3. Dans Autowalk, créer devant chaque porte une région « porte-auto » avec le paramètre `DoorID`
   (P01…P06). La région commence au point d'attente, hors du mouvement du rideau, et finit après
   le dégagement complet de Spot.

## Portes à fermeture commandée (relais K2)

Certaines portes ne se referment pas seules. Pour elles :

1. Câblage : contact K2 (COM2/NO2) en parallèle du **bouton de fermeture** (contact NO,
   jamais l'arrêt ni l'arrêt d'urgence), par les fils 5 et 6 du câble (bornes X2.5 / X2.6).
2. Carte : `set close 1` au port série, puis `reboot` ; `test_close` sur banc. Par défaut
   (`close 0`), la carte refuse toute fermeture (409 `close_disabled`).
3. `doors.yaml` : `close_mode: commande`, `close_time_s` (descente mesurée), `close_vision`
   (caméra arrière `back_depth`, `door_plane_x_m` négatif : la porte est derrière Spot).
4. Autowalk : la **fin** de la région « porte-auto » est la zone X, après la porte, Spot
   entièrement dégagé du rideau. Spot s'y arrête, journalise « arrivé en zone X, je peux
   fermer la porte », vérifie avec la caméra arrière que personne n'est sous la porte,
   envoie UNE impulsion K2, vérifie que la porte est fermée (2e impulsion au plus), puis
   repart. Un échec est une alerte au journal ; la mission continue.

API : `POST /api/v1/close` (même jeton, `door_id`, `op_id` idempotent). Verrous du module :
jamais K1 et K2 ensemble, pas de fermeture moins de 2 s après une ouverture (et inversement).
Mode natif : `spot_native_access_control.json` (OPEN + CLOSE) pour les portes à fermeture
commandée ; `spot_native_access_control_portes_auto.json` (OPEN seulement) pour les autres.

## Calibration de chaque porte (obligatoire)

- Mesurer : délai impulsion → porte ouverte, temps d'ouverture maintenue (`hold_open_s`), temps
  de franchissement de Spot (`crossing_time_s`), effet d'une 2ᵉ impulsion porte ouverte
  (`repulse_resets_timer`).
- `cli collect` : images porte fermée, mi-hauteur, ouverte, passage encombré, éclairages différents.
- `cli watch` : régler `door_plane_x_m`, `floor_z_m`, `max_points_in_box`, `min_valid_points`
  jusqu'à zéro faux « libre » sur le jeu d'essai.

## Sécurité

- Le module ne fait qu'ajouter un appui sur le bouton vert : arrêt d'urgence, fins de course et
  protections de la porte restent ceux du constructeur. Raccordement par personnel habilité.
- Vérifier que la protection de passage de la porte (cellule, barrière) détecte Spot.
- En cas de doute (module muet, vision inconnue, délai), le service bloque le passage.
- Jetons hors du code, un seul jeton par site, à changer si une carte est perdue. Modules sur un
  réseau ou VLAN dédié validé par l'informatique CCEP.
