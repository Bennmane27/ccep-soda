#!/usr/bin/env bash
# Construit l'Extension Spot (.spx) pour le CORE I/O depuis un PC Linux avec Docker.
# Prérequis ARM64 : docker buildx + qemu (docker run --privileged --rm tonistiigi/binfmt --install arm64)
set -euo pipefail
cd "$(dirname "$0")/.."
BUILD=extension/build
rm -rf "$BUILD" && mkdir -p "$BUILD"

docker buildx build --platform linux/arm64 -f extension/Dockerfile.coreio -t spot-doors:l4t --load .
docker save spot-doors:l4t | gzip > "$BUILD/spot-doors-image.tgz"

cp extension/manifest.json extension/docker-compose.yml "$BUILD/"
cp config/doors.example.yaml "$BUILD/doors.yaml"
[ -f config/secrets.env ] && cp config/secrets.env "$BUILD/secrets.env" || \
  echo "ATTENTION : config/secrets.env absent -> à créer sur le CORE I/O avant démarrage"

(cd "$BUILD" && tar zcfv ../spot_doors.spx ./*)
echo "Extension prête : extension/spot_doors.spx (installation : interface web du CORE I/O > Extensions)"
