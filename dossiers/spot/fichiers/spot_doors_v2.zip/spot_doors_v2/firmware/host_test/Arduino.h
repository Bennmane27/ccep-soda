// Bouchons minimaux de l'API Arduino-ESP32 pour compiler et tester door_node.ino sur PC.
#pragma once
#include <string>
#include <cstdio>
#include <cstdint>
#include <cstdarg>
#include <cstring>
#include <map>
#include <vector>
#include <deque>
#include <cstdlib>
#define F(x) x
#define HIGH 1
#define LOW 0
#define OUTPUT 1
#define INPUT 0
extern uint32_t g_millis;
inline uint32_t millis() { return g_millis; }
inline void delay(uint32_t ms) { g_millis += ms; }
extern std::map<int,int> g_pins;
inline void pinMode(int, int) {}
inline void digitalWrite(int p, int v) { g_pins[p] = v; }
inline int digitalRead(int p) { return g_pins.count(p) ? g_pins[p] : 0; }

class String {
 public:
  std::string s;
  String() {}
  String(const char *c) : s(c ? c : "") {}
  String(const std::string &x) : s(x) {}
  String(char c) : s(1, c) {}
  String(int v) : s(std::to_string(v)) {}
  String(unsigned int v) : s(std::to_string(v)) {}
  String(long v) : s(std::to_string(v)) {}
  String(unsigned long v) : s(std::to_string(v)) {}
  size_t length() const { return s.size(); }
  const char *c_str() const { return s.c_str(); }
  char operator[](size_t i) const { return s[i]; }
  bool operator==(const String &o) const { return s == o.s; }
  bool operator==(const char *o) const { return s == o; }
  bool operator!=(const String &o) const { return s != o.s; }
  String &operator+=(const String &o) { s += o.s; return *this; }
  String &operator+=(const char *o) { s += o; return *this; }
  String &operator+=(char c) { s += c; return *this; }
  bool startsWith(const String &p) const { return s.compare(0, p.s.size(), p.s) == 0; }
  int indexOf(char c, int from = 0) const { auto r = s.find(c, from); return r == std::string::npos ? -1 : (int)r; }
  int indexOf(const String &x, int from = 0) const { auto r = s.find(x.s, from); return r == std::string::npos ? -1 : (int)r; }
  int indexOf(const char *x, int from = 0) const { return indexOf(String(x), from); }
  String substring(size_t a) const { return a >= s.size() ? String() : String(s.substr(a)); }
  String substring(size_t a, size_t b) const { if (a >= s.size()) return String(); return String(s.substr(a, b > a ? b - a : 0)); }
  void trim() { size_t a = s.find_first_not_of(" \t\r\n"); size_t b = s.find_last_not_of(" \t\r\n"); s = (a == std::string::npos) ? "" : s.substr(a, b - a + 1); }
  long toInt() const { return atol(s.c_str()); }
};
inline String operator+(const String &a, const String &b) { return String(a.s + b.s); }
inline String operator+(const String &a, const char *b) { return String(a.s + b); }
inline String operator+(const char *a, const String &b) { return String(std::string(a) + b.s); }
inline String operator+(const String &a, long b) { return String(a.s + std::to_string(b)); }
inline String operator+(const String &a, unsigned long b) { return String(a.s + std::to_string(b)); }
inline String operator+(const String &a, int b) { return String(a.s + std::to_string(b)); }
inline String operator+(const String &a, unsigned int b) { return String(a.s + std::to_string(b)); }

struct SerialMock {
  std::deque<char> in;
  std::string out;
  void begin(int) {}
  int available() { return (int)in.size(); }
  int read() { char c = in.front(); in.pop_front(); return c; }
  void println() { out += "\n"; }
  void println(const char *x) { out += x; out += "\n"; }
  void println(const String &x) { println(x.c_str()); }
  int printf(const char *fmt, ...) { char b[512]; va_list ap; va_start(ap, fmt); int n = vsnprintf(b, sizeof b, fmt, ap); va_end(ap); out += b; return n; }
  void feed(const std::string &x) { for (char c : x) in.push_back(c); }
};
extern SerialMock Serial;

struct EspMock { void restart() { throw 42; } };
extern EspMock ESP;
