#pragma once
#include "Arduino.h"
extern std::map<std::string, std::string> g_nvs;
class Preferences {
 public:
  void begin(const char *, bool) {}
  void end() {}
  String getString(const char *k, const char *d) { return g_nvs.count(k) ? String(g_nvs[k]) : String(d); }
  uint32_t getUInt(const char *k, uint32_t d) { return g_nvs.count(k) ? (uint32_t)atol(g_nvs[k].c_str()) : d; }
  int getInt(const char *k, int d) { return g_nvs.count(k) ? atoi(g_nvs[k].c_str()) : d; }
  bool getBool(const char *k, bool d) { return g_nvs.count(k) ? g_nvs[k] == "1" : d; }
  void putString(const char *k, const String &v) { g_nvs[k] = v.s; }
  void putUInt(const char *k, uint32_t v) { g_nvs[k] = std::to_string(v); }
  void putInt(const char *k, int v) { g_nvs[k] = std::to_string(v); }
  void putBool(const char *k, bool v) { g_nvs[k] = v ? "1" : "0"; }
};
