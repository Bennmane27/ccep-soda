#pragma once
#include "Arduino.h"
#include <functional>
enum HTTPMethod { HTTP_GET, HTTP_POST };
class WebServer {
 public:
  std::map<std::string, std::function<void()>> routes;
  std::function<void()> nf;
  std::map<std::string, String> args, headers;
  int lastCode = 0; String lastBody;
  WebServer(int) {}
  void collectHeaders(const char **, int) {}
  void on(const char *path, HTTPMethod m, std::function<void()> f) { routes[std::to_string(m) + path] = f; }
  void onNotFound(std::function<void()> f) { nf = f; }
  void begin() {}
  void handleClient() {}
  String header(const char *k) { return headers.count(k) ? headers[k] : String(); }
  bool hasArg(const char *k) { return args.count(k) > 0; }
  String arg(const char *k) { return args[k]; }
  void sendHeader(const char *, const char *) {}
  void send(int code, const char *, const String &body) { lastCode = code; lastBody = body; }
  // Aide de test
  void call(HTTPMethod m, const std::string &path) { auto k = std::to_string(m) + path; if (routes.count(k)) routes[k](); else nf(); }
};
