#pragma once
#include "Arduino.h"
#define WIFI_STA 1
struct IPAddressMock { String toString() const { return String("10.0.0.41"); } };
struct WiFiMock {
  bool connected = true;
  void mode(int) {}
  void setAutoReconnect(bool) {}
  void setHostname(const char *) {}
  void begin(const char *, const char *) {}
  void disconnect() {}
  bool isConnected() { return connected; }
  int RSSI() { return -60; }
  IPAddressMock localIP() { return IPAddressMock(); }
};
extern WiFiMock WiFi;
