// Test hôte du firmware door_node : compile le .ino avec des bouchons et vérifie la logique.
#include "Arduino.h"
uint32_t g_millis = 0;
std::map<int,int> g_pins;
std::map<std::string, std::string> g_nvs;
SerialMock Serial;
EspMock ESP;
#include "WiFi.h"
WiFiMock WiFi;
#include "../door_node/door_node.ino"
#include <cassert>
#include <iostream>

static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::cerr << "ECHEC ligne " << __LINE__ << ": " #c "\n"; fails++; } } while (0)

static void runFor(uint32_t ms) { for (uint32_t i = 0; i < ms; i += 2) loop(); }
static const std::string TOKEN = "jeton-de-test-0123456789";
static void req(HTTPMethod m, const std::string &path, const std::string &tok, std::map<std::string, String> args = {}) {
  server.headers.clear(); server.args = args;
  if (!tok.empty()) server.headers["Authorization"] = String(("Bearer " + tok).c_str());
  server.call(m, path);
}
static bool relayOn() { return g_pins[RELAY_OPEN_PIN] == HIGH; }
static bool k2On() { return g_pins[RELAY_CLOSE_PIN] == HIGH; }
static bool has(const std::string &x) { return server.lastBody.s.find(x) != std::string::npos; }

int main() {
  // 1) Démarrage sans configuration : relais au repos, pas de serveur.
  g_pins[RELAY_OPEN_PIN] = HIGH;  // état parasite avant setup
  g_pins[RELAY_CLOSE_PIN] = HIGH;
  setup();
  CHECK(!relayOn());
  CHECK(!k2On());
  CHECK(server.routes.empty());

  // 2) Configuration par le port série puis redémarrage logique.
  Serial.feed("set door_id P01\nset ssid USINE\nset wifi_pass x\nset token court\nset token " + TOKEN + "\nset pulse_ms 99999\n");
  runFor(10);
  CHECK(Serial.out.find("jeton trop court") != std::string::npos);
  setup();
  CHECK(configValid());
  CHECK(cfg.pulseMs == PULSE_MAX_MS);  // borné à 2000 ms
  Serial.feed("set pulse_ms 500\n"); runFor(4); setup();
  CHECK(cfg.pulseMs == 500);
  CHECK(Serial.out.find(TOKEN) == std::string::npos);  // jeton jamais affiché

  // 3) Authentification.
  req(HTTP_GET, "/api/v1/health", "");
  CHECK(server.lastCode == 200);
  req(HTTP_GET, "/api/v1/status", "");
  CHECK(server.lastCode == 401);
  req(HTTP_POST, "/api/v1/open", "mauvais-jeton-0123456789");
  CHECK(server.lastCode == 401 && !relayOn());

  // 4) Impulsion unique de 500 ms.
  req(HTTP_POST, "/api/v1/open", TOKEN, {{"op_id", "A1"}, {"door_id", "P01"}});
  CHECK(server.lastCode == 200);
  CHECK(server.lastBody.s.find("\"pulsed\":true") != std::string::npos);
  CHECK(relayOn());
  runFor(480); CHECK(relayOn());
  runFor(40);  CHECK(!relayOn());
  runFor(2000); CHECK(!relayOn());  // jamais de répétition

  // 5) Rejeu de la même opération : pas de nouvelle impulsion.
  g_millis += 5000;
  req(HTTP_POST, "/api/v1/open", TOKEN, {{"op_id", "A1"}});
  CHECK(server.lastBody.s.find("duplicate_op_id") != std::string::npos && !relayOn());

  // 6) Anti-rebond : deux demandes rapprochées -> une seule impulsion.
  req(HTTP_POST, "/api/v1/open", TOKEN, {{"op_id", "B1"}});
  CHECK(relayOn());
  runFor(600);
  req(HTTP_POST, "/api/v1/open", TOKEN, {{"op_id", "B2"}});
  CHECK(server.lastBody.s.find("cooldown") != std::string::npos && !relayOn());
  CHECK(pulseCount == 2);

  // 7) Mauvaise porte.
  g_millis += 5000;
  req(HTTP_POST, "/api/v1/open", TOKEN, {{"door_id", "P02"}});
  CHECK(server.lastCode == 409 && !relayOn());

  // 8) CLOSE sur une porte qui se referme seule (close=0, défaut) : refus 409, aucune impulsion.
  req(HTTP_POST, "/api/v1/close", TOKEN, {{"op_id", "F0"}});
  CHECK(server.lastCode == 409 && has("close_disabled") && !k2On() && !relayOn());
  CHECK(closeCount == 0 && pulseCount == 2);
  Serial.out.clear(); Serial.feed("test_close\n"); runFor(4);
  CHECK(Serial.out.find("desactivee") != std::string::npos && !k2On());

  // 9) Statut.
  req(HTTP_GET, "/api/v1/status", TOKEN);
  CHECK(server.lastBody.s.find("\"mode\":\"auto\"") != std::string::npos);
  CHECK(server.lastBody.s.find("\"door_id\":\"P01\"") != std::string::npos);
  CHECK(server.lastBody.s.find(TOKEN) == std::string::npos);

  // 10) Redémarrage pendant une impulsion : relais relâché au démarrage.
  req(HTTP_POST, "/api/v1/open", TOKEN, {{"op_id", "C1"}});
  CHECK(relayOn());
  setup();
  CHECK(!relayOn());

  // 11) Fermeture commandée activée : une impulsion K2 de 500 ms, K1 reste au repos.
  CHECK(Serial.out.find("close     : 0") != std::string::npos);
  Serial.feed("set close 1\n"); runFor(4); setup();
  CHECK(cfg.closeEnabled);
  g_millis += 10000;
  req(HTTP_GET, "/api/v1/status", TOKEN);
  CHECK(has("\"close_enabled\":true") && has("\"close_count\":0") && has("\"ms_since_last_close\":-1"));
  req(HTTP_POST, "/api/v1/close", TOKEN, {{"op_id", "F1"}, {"door_id", "P01"}});
  CHECK(server.lastCode == 200 && has("\"pulsed\":true") && has("\"relay\":\"K2\""));
  CHECK(k2On() && !relayOn());
  runFor(480); CHECK(k2On());
  runFor(40);  CHECK(!k2On());
  runFor(2000); CHECK(!k2On());  // jamais de répétition
  CHECK(closeCount == 1);

  // 12) Rejeu de la même fermeture : pas de 2e impulsion. Même op_id en ouverture : traité à part.
  g_millis += 5000;
  req(HTTP_POST, "/api/v1/close", TOKEN, {{"op_id", "F1"}});
  CHECK(has("duplicate_op_id") && !k2On() && closeCount == 1);

  // 13) Verrous : fermeture moins de 2 s après une ouverture, et inversement.
  req(HTTP_POST, "/api/v1/open", TOKEN, {{"op_id", "G1"}});
  CHECK(relayOn());
  req(HTTP_POST, "/api/v1/close", TOKEN, {{"op_id", "G2"}});
  CHECK(has("pulse_in_progress") && !k2On());          // jamais K1 et K2 ensemble
  runFor(600);
  req(HTTP_POST, "/api/v1/close", TOKEN, {{"op_id", "G3"}});
  CHECK(server.lastCode == 409 && has("too_soon_after_open") && !k2On());
  runFor(1600);
  req(HTTP_POST, "/api/v1/close", TOKEN, {{"op_id", "G4"}});
  CHECK(server.lastCode == 200 && has("\"pulsed\":true") && k2On());
  runFor(600);
  req(HTTP_POST, "/api/v1/close", TOKEN, {{"op_id", "G5"}});
  CHECK(has("cooldown") && !k2On());                    // anti-rebond propre à la fermeture
  g_millis += 3500;                                     // cooldown d'ouverture écoulé
  runFor(2);
  uint32_t sinceClose = millis() - lastCloseMs;
  CHECK(sinceClose < INTERLOCK_MS + 2500);
  // ouverture < 2 s après une fermeture
  req(HTTP_POST, "/api/v1/close", TOKEN, {{"op_id", "G6"}});
  CHECK(k2On());
  runFor(600);
  req(HTTP_POST, "/api/v1/open", TOKEN, {{"op_id", "G7"}});
  CHECK(server.lastCode == 409 && has("too_soon_after_close") && !relayOn());
  CHECK(closeCount == 3);

  // 14) test_close sur banc et statut.
  g_millis += 5000;
  Serial.out.clear(); Serial.feed("test_close\n"); runFor(4);
  CHECK(Serial.out.find("test_close : OK") != std::string::npos && k2On());
  runFor(600); CHECK(!k2On());
  req(HTTP_GET, "/api/v1/status", TOKEN);
  CHECK(has("\"close_count\":4"));

  // 15) Redémarrage pendant une impulsion K2 : relais relâché au démarrage.
  g_millis += 5000;
  req(HTTP_POST, "/api/v1/close", TOKEN, {{"op_id", "H1"}});
  CHECK(k2On());
  setup();
  CHECK(!k2On() && !relayOn());

  std::cout << (fails ? "ECHECS: " + std::to_string(fails) : std::string("Tous les tests firmware passent")) << "\n";
  return fails ? 1 : 0;
}
