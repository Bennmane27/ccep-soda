"""spot_doors — ouverture autonome des portes automatiques par Spot (mode auto)."""
__version__ = "2.0.0"
