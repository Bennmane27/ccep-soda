"""Service Area Callback "porte-auto" pour GraphNav (exécuté sur le CORE I/O ou un PC).

Lors de l'enregistrement Autowalk, on crée devant chaque porte une région liée à ce
service et on renseigne son paramètre "DoorID" (ex. P01). En mission :

  - Spot s'arrête au début de la région (point d'attente devant la porte) ;
  - le service demande l'ouverture et attend la confirmation du passage ;
  - si tout est confirmé et qu'il reste le temps de passer, Spot reprend sa route ;
  - sinon le service signale le chemin bloqué (PathBlocked) : GraphNav cherche une autre
    route ou la mission échoue proprement. Spot n'avance jamais vers une porte non confirmée.

Portes à fermeture commandée (close_mode "commande" dans doors.yaml) : la FIN de la région
est la zone X, placée après la porte, Spot entièrement dégagé du rideau. Spot s'y arrête
(stop_at_end), annonce « arrivé en zone X, je peux fermer la porte », vérifie avec sa caméra
arrière que personne n'est sous la porte, demande la fermeture (relais K2), vérifie que la
porte est fermée, puis reprend sa mission. Un échec de fermeture est une alerte au journal,
jamais un blocage de la mission.

Lancement (CORE I/O, dans l'Extension) :
  python3 -m spot_doors.area_callback_service 192.168.50.3 \
      --payload-credentials-file /opt/payload_credentials/payload_guid_and_secret \
      --config /config/doors.yaml
Lancement depuis un PC de développement : identifiants via BOSDYN_CLIENT_USERNAME /
BOSDYN_CLIENT_PASSWORD (variables d'environnement lues par le SDK).
"""
from __future__ import annotations

import argparse
import logging
import os
from pathlib import Path

import bosdyn.client
import bosdyn.client.util
from bosdyn.api import service_customization_pb2
from bosdyn.api.graph_nav import area_callback_pb2
from bosdyn.client import service_customization_helpers as sch
from bosdyn.client.area_callback_region_handler_base import (AreaCallbackRegionHandlerBase,
                                                             PathBlocked)
from bosdyn.client.area_callback_service_runner import run_service
from bosdyn.client.area_callback_service_servicer import AreaCallbackServiceServicer
from bosdyn.client.area_callback_service_utils import AreaCallbackServiceConfig
from bosdyn.client.robot import Robot

from .config import ConfigError, SiteConfig, load_site_config
from .controller import DoorPassageController
from .journal import Journal
from .transport import HttpDoorTransport
from .vision import AllOfObserver, NodeInputObserver, PassageObserver, SpotDepthObserver

LOGGER = logging.getLogger("spot_doors")
SERVICE_NAME = "porte-auto"
DEFAULT_PORT = 21100

# Partagés par toutes les régions (fixés dans main()).
SITE: SiteConfig | None = None
JOURNAL: Journal | None = None
TRANSPORT = HttpDoorTransport()


def build_observer(robot: Robot, door) -> PassageObserver:
    method = door.vision.method
    depth = lambda: SpotDepthObserver(robot, door.vision)
    node = lambda: NodeInputObserver(TRANSPORT, door)
    if method == "depth":
        return depth()
    if method == "input":
        return node()
    return AllOfObserver([depth(), node()])


def build_close_observer(robot: Robot, door) -> PassageObserver:
    """Observateur de la fermeture : caméra arrière (close_vision) et/ou contact du module."""
    method = door.close_vision.method
    depth = lambda: SpotDepthObserver(robot, door.close_vision)
    node = lambda: NodeInputObserver(TRANSPORT, door)
    if method == "depth":
        return depth()
    if method == "input":
        return node()
    return AllOfObserver([depth(), node()], require_all_blocked=True)


class DoorRegionHandler(AreaCallbackRegionHandlerBase):

    def __init__(self, config: AreaCallbackServiceConfig, robot: Robot):
        super().__init__(config, robot)
        self.robot = robot
        self.door_id = None
        self.starting_inside = False
        self.stop_at_start()       # attendre devant la porte
        self.continue_past_end()   # reprendre la mission après la porte

    def begin(self, request: area_callback_pb2.BeginCallbackRequest):
        try:
            params = self.config.parse_params(request.custom_params)
        except Exception as exc:
            LOGGER.error("Paramètres de région invalides : %s", exc)
            return area_callback_pb2.BeginCallbackResponse.STATUS_CUSTOM_PARAMS_ERROR
        self.door_id = (params.get("door_id") or "").strip()
        self.starting_inside = request.region_info.starting_inside_region
        try:
            door = SITE.door(self.door_id)
        except ConfigError as exc:
            LOGGER.error("%s", exc)
            JOURNAL.event(self.door_id or "?", "config_error", error=str(exc))
            return area_callback_pb2.BeginCallbackResponse.STATUS_CUSTOM_PARAMS_ERROR
        if door.closes_on_command:
            self.stop_at_end()     # Spot attend en zone X que la fermeture soit traitée
        return area_callback_pb2.BeginCallbackResponse.STATUS_OK

    def run(self):
        door = SITE.door(self.door_id)
        if not self.starting_inside:
            self.block_until_arrived_at_start()
        JOURNAL.event(door.door_id, "arrived", starting_inside=self.starting_inside)

        controller = DoorPassageController(
            door, TRANSPORT, build_observer(self.robot, door), JOURNAL,
            sleep=self.safe_sleep,  # safe_sleep interrompt proprement si la mission s'arrête
            close_observer=build_close_observer(self.robot, door) if door.closes_on_command else None)

        result = controller.open_and_confirm()
        if not result.ok:
            JOURNAL.event(door.door_id, "blocked", outcome=result.outcome.value,
                          detail=result.detail, attempts=result.attempts)
            raise PathBlocked(f"{door.door_id}: {result.outcome.value} ({result.detail})")

        timing = controller.ensure_time_to_cross()
        if not timing.ok:
            JOURNAL.event(door.door_id, "blocked", outcome=timing.outcome.value,
                          detail=timing.detail)
            raise PathBlocked(f"{door.door_id}: {timing.outcome.value}")

        JOURNAL.event(door.door_id, "crossing", seconds_since_pulse=round(
            controller.seconds_since_pulse() or 0.0, 2))
        self.continue_past_start()
        self.block_until_arrived_at_end()
        JOURNAL.event(door.door_id, "crossed", seconds_since_pulse=round(
            controller.seconds_since_pulse() or 0.0, 2))

        if door.closes_on_command:
            # Fin de la région = zone X : Spot y est arrêté (stop_at_end posé dans begin()).
            closing = controller.close_and_confirm()
            JOURNAL.event(door.door_id, "close_result", outcome=closing.outcome.value,
                          attempts=closing.attempts, detail=closing.detail,
                          alert=not closing.ok)
            if not closing.ok:
                LOGGER.warning("%s : fermeture non confirmée (%s) — vérification humaine",
                               door.door_id, closing.outcome.value)
            self.continue_past_end()   # la mission continue dans tous les cas

    def end(self):
        # Portes "auto" : l'automatisme referme après sa temporisation. Portes "commande" :
        # la fermeture a été traitée en zone X dans run().
        JOURNAL.event(self.door_id or "?", "region_end")


def make_service_config() -> AreaCallbackServiceConfig:
    config = AreaCallbackServiceConfig(SERVICE_NAME)
    info = config.area_callback_information

    ui = service_customization_pb2.UserInterfaceInfo(display_name="DoorID")
    door_spec = sch.make_dict_child_spec(
        sch.make_string_param_spec(options=None, editable=True, default_value=""), ui_info=ui)
    info.custom_params.CopyFrom(sch.make_dict_param_spec(specs={"door_id": door_spec},
                                                         is_hidden_by_default=False))
    # La porte fermée est un obstacle attendu avant l'ouverture : on laisse GraphNav vérifier
    # les blocages, le service se charge de rendre le passage libre avant de lâcher Spot.
    info.blockage = info.BLOCKAGE_CHECK
    info.impairment_check = info.IMPAIRMENT_CHECK
    info.entity_waiting = info.ENTITY_WAITING_ENABLE
    info.default_stop.face_direction = info.default_stop.FACE_DIRECTION_ALONG_ROUTE
    return config


def main(argv=None):
    global SITE, JOURNAL
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    bosdyn.client.util.add_base_arguments(parser)
    bosdyn.client.util.add_payload_credentials_arguments(parser, required=False)
    parser.add_argument("--config", default=os.environ.get("SPOT_DOORS_CONFIG",
                                                          "/config/doors.yaml"))
    parser.add_argument("--port", type=int, default=DEFAULT_PORT,
                        help="port gRPC du service (défaut 21100)")
    parser.add_argument("--host-ip", default=None,
                        help="IP de cette machine vue par le robot (auto si absent)")
    options = parser.parse_args(argv)
    bosdyn.client.util.setup_logging(options.verbose)

    SITE = load_site_config(Path(options.config))
    JOURNAL = Journal(SITE.log_dir)
    for door in SITE.doors.values():
        door.token()  # échoue au démarrage si un jeton manque, pas pendant la mission
    LOGGER.info("Portes configurées : %s", ", ".join(SITE.doors))

    sdk = bosdyn.client.create_standard_sdk("SpotDoorsAreaCallback")
    robot = sdk.create_robot(options.hostname)
    if options.payload_credentials_file or (options.guid and options.secret):
        robot.authenticate_from_payload_credentials(
            *bosdyn.client.util.get_guid_and_secret(options))
    else:
        bosdyn.client.util.authenticate(robot)
    robot.start_time_sync()
    robot.time_sync.wait_for_sync()

    self_ip = options.host_ip or bosdyn.client.common.get_self_ip(options.hostname)
    servicer = AreaCallbackServiceServicer(robot, make_service_config(), DoorRegionHandler)
    service_runner, keep_alive = run_service(robot, servicer, options.port, self_ip)
    with keep_alive:
        service_runner.run_until_interrupt()


if __name__ == "__main__":
    main()
