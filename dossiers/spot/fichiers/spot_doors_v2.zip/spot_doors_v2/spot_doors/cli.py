"""Outils de mise au point, à lancer depuis un PC ou le CORE I/O.

  python3 -m spot_doors.cli status  --config doors.yaml --door P01
  python3 -m spot_doors.cli open    --config doors.yaml --door P01      # une impulsion réelle !
  python3 -m spot_doors.cli close   --config doors.yaml --door P03      # impulsion K2 réelle !
  python3 -m spot_doors.cli watch   --config doors.yaml --door P01 --robot 192.168.80.3
  python3 -m spot_doors.cli collect --robot 192.168.80.3 --sources frontleft_depth \
        frontright_depth frontleft_fisheye_image --out images_P01 --label fermee

`watch` affiche en continu le verdict de la vision (libre / encombré / inconnu) sans rien
commander : c'est l'outil de calibration des seuils. `collect` enregistre des images
horodatées et étiquetées pour constituer le jeu d'essai de chaque porte.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

from .config import load_site_config
from .transport import HttpDoorTransport


def _robot(hostname: str):
    import bosdyn.client
    import bosdyn.client.util
    sdk = bosdyn.client.create_standard_sdk("SpotDoorsCli")
    robot = sdk.create_robot(hostname)
    bosdyn.client.util.authenticate(robot)
    robot.time_sync.wait_for_sync()
    return robot


def cmd_status(a):
    door = load_site_config(a.config).door(a.door)
    print(HttpDoorTransport().status(door))


def cmd_open(a):
    door = load_site_config(a.config).door(a.door)
    if not a.yes:
        answer = input(f"Envoyer une impulsion d'ouverture RÉELLE à {door.door_id} ({door.name}) ? [oui/non] ")
        if answer.strip().lower() != "oui":
            print("Annulé.")
            return
    print(HttpDoorTransport().open(door))


def cmd_close(a):
    door = load_site_config(a.config).door(a.door)
    if not door.closes_on_command:
        print(f"{door.door_id} est en close_mode 'auto' : la porte se referme seule, rien à envoyer.")
        return
    if not a.yes:
        answer = input(f"Envoyer une impulsion de FERMETURE RÉELLE à {door.door_id} ({door.name}) ? "
                       "Vérifier que personne n'est sous la porte. [oui/non] ")
        if answer.strip().lower() != "oui":
            print("Annulé.")
            return
    print(HttpDoorTransport().close(door))


def cmd_watch(a):
    from .vision import SpotDepthObserver
    door = load_site_config(a.config).door(a.door)
    vision = door.close_vision if a.arriere else door.vision
    observer = SpotDepthObserver(_robot(a.robot), vision)
    try:
        while True:
            obs = observer.observe()
            print(f"{time.strftime('%H:%M:%S')}  {obs.state.value:9s}  points_gabarit={obs.points_in_box:5d}"
                  f"  points_valides={obs.valid_points:6d}  {obs.detail}")
            time.sleep(vision.period_s)
    except KeyboardInterrupt:
        pass


def cmd_collect(a):
    from bosdyn.client.image import ImageClient, save_images_as_files
    robot = _robot(a.robot)
    client = robot.ensure_client(ImageClient.default_service_name)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    for i in range(a.count):
        stamp = time.strftime("%Y%m%d_%H%M%S")
        responses = client.get_image_from_sources(a.sources)
        save_images_as_files(responses, filename=f"{a.label}_{stamp}_{i:03d}", filepath=str(out))
        time.sleep(a.period)
    print(f"{a.count} séries enregistrées dans {out}")


def main(argv=None):
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name, fn in (("status", cmd_status), ("open", cmd_open), ("close", cmd_close),
                     ("watch", cmd_watch)):
        s = sub.add_parser(name)
        s.add_argument("--config", required=True)
        s.add_argument("--door", required=True)
        if name in ("open", "close"):
            s.add_argument("--yes", action="store_true", help="ne pas demander de confirmation")
        if name == "watch":
            s.add_argument("--robot", required=True)
            s.add_argument("--arriere", action="store_true",
                           help="caméra arrière, gabarit de fermeture (close_vision)")
        s.set_defaults(fn=fn)
    c = sub.add_parser("collect")
    c.add_argument("--robot", required=True)
    c.add_argument("--sources", nargs="+", required=True)
    c.add_argument("--out", required=True)
    c.add_argument("--label", required=True, help="ex. fermee, mi_hauteur, ouverte, encombree")
    c.add_argument("--count", type=int, default=10)
    c.add_argument("--period", type=float, default=0.5)
    c.set_defaults(fn=cmd_collect)
    a = p.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
