"""Chargement et validation de la configuration des portes.

La configuration (doors.yaml) décrit chaque porte : identifiant, adresse du module,
temps mesurés, paramètres de vision et mode de fermeture :
  - close_mode "auto" (défaut) : la porte se referme seule après sa temporisation ;
  - close_mode "commande" : la porte reste ouverte ; Spot demande la fermeture (relais K2,
    en parallèle du bouton de fermeture) en arrivant en zone X, après la porte, puis vérifie
    avec sa caméra arrière que la porte est bien fermée. Les secrets (jetons) n'y figurent jamais :
ils viennent de variables d'environnement ou d'un fichier monté séparément.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

CLOSE_MODES = ("auto", "commande")

import yaml


class ConfigError(ValueError):
    """Configuration absente, incohérente ou incomplète."""


@dataclass(frozen=True)
class VisionConfig:
    # Méthode de confirmation : "depth" (caméras de Spot), "input" (contact "porte ouverte"
    # câblé sur le module), "both" (les deux doivent confirmer).
    method: str = "depth"
    # Sources de profondeur de Spot regardant la porte (vérifier avec get_image.py --list).
    depth_sources: tuple = ("frontleft_depth", "frontright_depth")
    # Boîte de contrôle exprimée dans le repère "body" du robot arrêté au point d'attente.
    # x : distance devant le robot, y : latéral (gauche positif), z : hauteur depuis le sol.
    door_plane_x_m: float = 1.8          # distance mesurée entre le robot arrêté et le plan de porte
    plane_tolerance_m: float = 0.35      # épaisseur de la tranche contrôlée autour du plan
    half_width_m: float = 0.55           # demi-largeur de passage contrôlée
    floor_z_m: float = -0.45             # hauteur du sol dans le repère body (à calibrer)
    clear_height_m: float = 1.0          # hauteur libre exigée au-dessus du sol (robot + charges + marge)
    max_points_in_box: int = 40          # au-delà : passage encombré (rideau, barre basse, personne)
    min_valid_points: int = 1500         # en dessous : observation inconnue (caméra masquée, trop sombre)
    max_image_age_s: float = 1.0         # image plus ancienne : inconnue
    stable_free_s: float = 1.0           # durée pendant laquelle "libre" doit être stable
    period_s: float = 0.2                # cadence d'observation visée (5 Hz)


@dataclass(frozen=True)
class DoorConfig:
    door_id: str
    name: str
    host: str                      # adresse IP ou nom DNS du module de porte
    port: int = 80
    token_env: str = "SPOT_DOOR_TOKEN"
    request_timeout_s: float = 2.0
    request_retries: int = 2
    # Temps propres à la porte (à mesurer sur site ; les valeurs par défaut sont prudentes)
    open_timeout_s: float = 20.0       # délai maxi entre l'impulsion et "passage libre" confirmé
    hold_open_s: float = 25.0          # temps pendant lequel la porte reste ouverte après impulsion
    crossing_time_s: float = 8.0       # temps mesuré pour que Spot franchisse complètement le seuil
    safety_margin_s: float = 5.0
    max_open_attempts: int = 2         # impulsions maximum avant d'abandonner
    repulse_resets_timer: bool = False # True seulement si l'essai prouve qu'une impulsion relance la tempo
    vision: VisionConfig = field(default_factory=VisionConfig)
    # Fermeture commandée (portes qui ne se referment pas seules)
    close_mode: str = "auto"                     # "auto" | "commande"
    close_time_s: float = 8.0                    # descente complète mesurée après l'impulsion K2
    close_confirm_timeout_s: Optional[float] = None  # défaut : close_time_s + 5
    max_close_attempts: int = 2                  # impulsions K2 maximum
    clear_before_close_timeout_s: float = 20.0   # attente maxi d'un passage libre derrière Spot
    closed_stable_s: float = 2.0                 # la porte doit être vue fermée pendant cette durée
    # Vision de la fermeture : caméra ARRIÈRE de Spot arrêté en zone X (porte derrière lui).
    close_vision: VisionConfig = field(default_factory=lambda: VisionConfig(
        depth_sources=("back_depth",), door_plane_x_m=-1.8))

    def __post_init__(self):
        if self.close_confirm_timeout_s is None:
            object.__setattr__(self, "close_confirm_timeout_s", self.close_time_s + 5.0)

    @property
    def closes_on_command(self) -> bool:
        return self.close_mode == "commande"

    def token(self) -> str:
        value = os.environ.get(self.token_env, "")
        if len(value) < 16:
            raise ConfigError(
                f"Jeton absent ou trop court pour la porte {self.door_id} "
                f"(variable d'environnement {self.token_env}).")
        return value

    @property
    def base_url(self) -> str:
        return f"http://{self.host}:{self.port}/api/v1"

    def crossing_fits(self, seconds_since_pulse: float) -> bool:
        """Vrai si Spot a le temps de franchir avant la fermeture temporisée.

        Une porte à fermeture commandée ne redescend pas seule : le temps ne manque jamais.
        """
        if self.closes_on_command:
            return True
        return (seconds_since_pulse + self.crossing_time_s + self.safety_margin_s
                <= self.hold_open_s)


@dataclass(frozen=True)
class SiteConfig:
    doors: Dict[str, DoorConfig]
    log_dir: Path = Path("/data/logs")

    def door(self, door_id: Optional[str]) -> DoorConfig:
        if not door_id:
            raise ConfigError("Aucun DoorID fourni par la région de la mission.")
        try:
            return self.doors[door_id]
        except KeyError:
            raise ConfigError(f"DoorID inconnu : {door_id!r}") from None


def _build_vision(raw: dict, defaults: dict) -> VisionConfig:
    merged = {**defaults, **(raw or {})}
    if "depth_sources" in merged:
        merged["depth_sources"] = tuple(merged["depth_sources"])
    unknown = set(merged) - set(VisionConfig.__dataclass_fields__)
    if unknown:
        raise ConfigError(f"Paramètres de vision inconnus : {sorted(unknown)}")
    vc = VisionConfig(**merged)
    if vc.method not in ("depth", "input", "both"):
        raise ConfigError(f"Méthode de confirmation inconnue : {vc.method!r}")
    return vc


def _validate_close(door: DoorConfig) -> None:
    d = door.door_id
    if door.close_mode not in CLOSE_MODES:
        raise ConfigError(f"{d}: close_mode inconnu {door.close_mode!r} (auto ou commande)")
    if door.close_time_s <= 0:
        raise ConfigError(f"{d}: close_time_s doit être positif")
    if door.close_confirm_timeout_s < door.close_time_s:
        raise ConfigError(f"{d}: close_confirm_timeout_s doit couvrir close_time_s")
    if door.max_close_attempts < 1:
        raise ConfigError(f"{d}: max_close_attempts doit valoir au moins 1")
    if door.clear_before_close_timeout_s <= 0 or door.closed_stable_s <= 0:
        raise ConfigError(f"{d}: délais de fermeture invalides")
    cv = door.close_vision
    if any(src.startswith("back") for src in cv.depth_sources) and cv.door_plane_x_m >= 0:
        raise ConfigError(f"{d}: la porte est derrière Spot en zone X, "
                          f"close_vision.door_plane_x_m doit être négatif")


# Valeurs propres à la vision de fermeture (le reste vient de la vision de la porte).
CLOSE_VISION_DEFAULTS = {"depth_sources": ("back_depth",), "door_plane_x_m": -1.8}


def load_site_config(path: Path | str) -> SiteConfig:
    path = Path(path)
    if not path.exists():
        raise ConfigError(f"Fichier de configuration introuvable : {path}")
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    defaults = raw.get("defaults", {}) or {}
    vision_defaults = defaults.pop("vision", {}) or {}
    close_vision_defaults = defaults.pop("close_vision", {}) or {}
    doors: Dict[str, DoorConfig] = {}
    for entry in raw.get("doors", []) or []:
        entry = dict(entry)
        entry_vision = entry.pop("vision", {}) or {}
        vision = _build_vision(entry_vision, vision_defaults)
        close_vision = _build_vision(
            {**CLOSE_VISION_DEFAULTS, **close_vision_defaults, **(entry.pop("close_vision", {}) or {})},
            {**vision_defaults, **entry_vision})
        params = {**defaults, **entry}
        unknown = set(params) - set(DoorConfig.__dataclass_fields__)
        if unknown:
            raise ConfigError(f"Paramètres inconnus pour {entry.get('door_id')}: {sorted(unknown)}")
        door = DoorConfig(vision=vision, close_vision=close_vision, **params)
        if door.door_id in doors:
            raise ConfigError(f"DoorID en double : {door.door_id}")
        _validate_close(door)
        if not door.closes_on_command and door.hold_open_s <= door.crossing_time_s + door.safety_margin_s:
            raise ConfigError(
                f"{door.door_id}: hold_open_s ({door.hold_open_s}) ne laisse pas le temps de "
                f"franchir (crossing_time_s + safety_margin_s).")
        doors[door.door_id] = door
    if not doors:
        raise ConfigError("Aucune porte déclarée dans la configuration.")
    log_dir = Path(raw.get("log_dir", "/data/logs"))
    return SiteConfig(doors=doors, log_dir=log_dir)
