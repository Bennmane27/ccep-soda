"""Logique de passage d'une porte automatique — indépendante du robot.

Séquence (mode auto uniquement) :
  1. vérifier que le module de la porte répond et annonce le bon identifiant ;
  2. envoyer UNE impulsion (op_id unique, rejouable sans double impulsion) ;
  3. observer le passage jusqu'à ce qu'il soit libre de façon stable, ou jusqu'au délai ;
  4. si le délai expire : nouvelle impulsion (dans la limite max_open_attempts), sinon échec ;
  5. avant de lâcher Spot, vérifier qu'il reste assez de temps avant la fermeture
     temporisée ; sinon relancer (si l'essai a prouvé que l'impulsion relance la tempo)
     ou refuser le passage.

Règle de sécurité : en cas de doute (module muet, vision inconnue, délai), le résultat
est un ÉCHEC. Le service ne laisse jamais Spot avancer vers une porte non confirmée.

Fermeture commandée (portes qui ne se referment pas seules, close_mode "commande") :
  1. Spot est arrêté en zone X, après la porte : « je suis arrivé en zone X, je peux fermer » ;
  2. la caméra arrière doit voir le passage libre (personne, rien sous la porte), sinon on
     ne ferme pas et la porte est signalée laissée ouverte ;
  3. UNE impulsion K2 (en parallèle du bouton de fermeture) ;
  4. la porte doit être vue fermée (rideau dans le plan de porte, stable) après sa durée de
     descente ; sinon une seconde impulsion, puis alerte. La fermeture ne bloque jamais la
     mission : l'échec est journalisé comme alerte.
"""
from __future__ import annotations

import enum
import time
from dataclasses import dataclass
from typing import Callable, Optional

from .config import DoorConfig
from .journal import Journal
from .transport import DoorTransport, DoorTransportError
from .vision import PassageObserver, PassageState, StabilityFilter


class Outcome(enum.Enum):
    PASSAGE_CONFIRMED = "passage_confirme"
    MODULE_UNREACHABLE = "module_injoignable"
    OPEN_TIMEOUT = "ouverture_non_confirmee"
    NOT_ENOUGH_TIME = "temps_insuffisant_avant_fermeture"
    CANCELLED = "annule"
    DOOR_CLOSED = "porte_fermee"
    CLOSE_NOT_CONFIRMED = "fermeture_non_confirmee"
    CLOSE_SKIPPED_PASSAGE_OCCUPIED = "fermeture_annulee_passage_occupe"
    CLOSE_NOT_REQUIRED = "fermeture_automatique"


@dataclass
class PassageResult:
    outcome: Outcome
    door_id: str
    attempts: int
    seconds_since_pulse: Optional[float] = None
    detail: str = ""

    @property
    def ok(self) -> bool:
        return self.outcome in (Outcome.PASSAGE_CONFIRMED, Outcome.DOOR_CLOSED,
                                Outcome.CLOSE_NOT_REQUIRED)


ACCEPTED_REASONS = {"pulsed", "duplicate_op_id", "cooldown", "pulse_in_progress"}
CLOSE_RETRY_REASONS = {"too_soon_after_open"}   # verrou de 2 s du module : on réessaie


class DoorPassageController:
    def __init__(self, door: DoorConfig, transport: DoorTransport, observer: PassageObserver,
                 journal: Journal, sleep: Callable[[float], None] = time.sleep,
                 clock: Callable[[], float] = time.monotonic,
                 cancelled: Callable[[], bool] = lambda: False,
                 close_observer: Optional[PassageObserver] = None):
        self.door = door
        self.transport = transport
        self.observer = observer
        # Fermeture : caméra arrière (la porte est derrière Spot en zone X).
        self.close_observer = close_observer or observer
        self.last_close_at: Optional[float] = None
        self.journal = journal
        self._sleep = sleep
        self._clock = clock
        self._cancelled = cancelled
        self.last_pulse_at: Optional[float] = None

    # ------------------------------------------------------------------ helpers
    def _log(self, event: str, **fields) -> None:
        self.journal.event(self.door.door_id, event, **fields)

    def _pulse(self, attempt: int) -> bool:
        try:
            ack = self.transport.open(self.door)
        except DoorTransportError as exc:
            self._log("pulse_failed", attempt=attempt, error=str(exc))
            return False
        if ack.reason not in ACCEPTED_REASONS:
            self._log("pulse_refused", attempt=attempt, reason=ack.reason, op_id=ack.op_id)
            return False
        # On date l'impulsion côté robot au moment de l'accusé (borne prudente).
        now = self._clock()
        if (not self.door.repulse_resets_timer and self.last_pulse_at is not None
                and now - self.last_pulse_at < self.door.hold_open_s):
            # Tant que l'essai n'a pas prouvé qu'une impulsion relance la temporisation,
            # la fermeture reste calée sur l'impulsion précédente : on garde celle-ci comme
            # référence (prudent), sinon Spot croirait avoir plus de temps qu'il n'en a.
            self._log("pulse_reference_kept", attempt=attempt,
                      seconds_since_reference=round(now - self.last_pulse_at, 2))
        else:
            self.last_pulse_at = now
        self._log("pulse_ack", attempt=attempt, pulsed=ack.pulsed, reason=ack.reason,
                  op_id=ack.op_id)
        return True

    def seconds_since_pulse(self) -> Optional[float]:
        if self.last_pulse_at is None:
            return None
        return self._clock() - self.last_pulse_at

    def _wait_for_free(self) -> Optional[str]:
        """Retourne None si passage libre stable, sinon un motif d'échec."""
        stab = StabilityFilter(self.door.vision.stable_free_s, clock=self._clock)
        deadline = self._clock() + self.door.open_timeout_s
        last_state = None
        while self._clock() < deadline:
            if self._cancelled():
                return "cancelled"
            obs = self.observer.observe()
            if obs.state is not last_state:
                self._log("vision", state=obs.state.value, points_in_box=obs.points_in_box,
                          valid_points=obs.valid_points, detail=obs.detail)
                last_state = obs.state
            if stab.update(obs):
                return None
            self._sleep(self.door.vision.period_s)
        return f"délai {self.door.open_timeout_s:.0f} s dépassé (dernier état : " \
               f"{last_state.value if last_state else 'aucun'})"

    # ------------------------------------------------------------------ public
    def open_and_confirm(self) -> PassageResult:
        door_id = self.door.door_id
        self._log("request", host=self.door.host)
        try:
            status = self.transport.status(self.door)
            self._log("node_ok", fw=status.fw, rssi=status.rssi)
        except DoorTransportError as exc:
            self._log("node_unreachable", error=str(exc))
            return PassageResult(Outcome.MODULE_UNREACHABLE, door_id, 0, detail=str(exc))

        attempts = 0
        detail = ""
        while attempts < self.door.max_open_attempts:
            if self._cancelled():
                return PassageResult(Outcome.CANCELLED, door_id, attempts)
            attempts += 1
            if not self._pulse(attempts):
                detail = "impulsion non acceptée"
                continue
            reason = self._wait_for_free()
            if reason is None:
                elapsed = self.seconds_since_pulse()
                self._log("passage_free", attempt=attempts, seconds_since_pulse=round(elapsed, 2))
                return PassageResult(Outcome.PASSAGE_CONFIRMED, door_id, attempts, elapsed)
            if reason == "cancelled":
                return PassageResult(Outcome.CANCELLED, door_id, attempts)
            detail = reason
            self._log("open_not_confirmed", attempt=attempts, reason=reason)

        outcome = (Outcome.OPEN_TIMEOUT if self.last_pulse_at is not None
                   else Outcome.MODULE_UNREACHABLE)
        return PassageResult(outcome, door_id, attempts, self.seconds_since_pulse(), detail)

    def ensure_time_to_cross(self) -> PassageResult:
        """À appeler juste avant de lâcher Spot dans la porte."""
        elapsed = self.seconds_since_pulse()
        door_id = self.door.door_id
        if elapsed is not None and self.door.crossing_fits(elapsed):
            return PassageResult(Outcome.PASSAGE_CONFIRMED, door_id, 0, elapsed)
        if not self.door.repulse_resets_timer:
            self._log("not_enough_time", seconds_since_pulse=elapsed)
            return PassageResult(Outcome.NOT_ENOUGH_TIME, door_id, 0, elapsed,
                                 "la temporisation restante ne couvre pas le franchissement")
        # L'essai sur site a montré qu'une impulsion porte ouverte relance la temporisation.
        if not self._pulse(attempt=0):
            return PassageResult(Outcome.NOT_ENOUGH_TIME, door_id, 0, elapsed,
                                 "relance de la temporisation refusée")
        reason = self._wait_for_free()
        if reason is not None:
            return PassageResult(Outcome.OPEN_TIMEOUT, door_id, 0, self.seconds_since_pulse(),
                                 reason)
        return PassageResult(Outcome.PASSAGE_CONFIRMED, door_id, 0, self.seconds_since_pulse())

    # ------------------------------------------------------------------ fermeture
    def _wait_clear_behind(self) -> bool:
        """Vrai si le passage derrière Spot est vu libre (stable) dans le délai prévu."""
        stab = StabilityFilter(self.door.close_vision.stable_free_s, clock=self._clock)
        deadline = self._clock() + self.door.clear_before_close_timeout_s
        last_state = None
        while self._clock() < deadline:
            if self._cancelled():
                return False
            obs = self.close_observer.observe()
            if obs.state is not last_state:
                self._log("close_vision", state=obs.state.value, detail=obs.detail)
                last_state = obs.state
            if stab.update(obs):
                return True
            self._sleep(self.door.close_vision.period_s)
        return False

    def _wait_closed(self, pulse_at: float) -> bool:
        """Vrai si la porte est vue fermée : ENCOMBRÉ stable `closed_stable_s`, et au moins
        `close_time_s` écoulées depuis l'impulsion (le temps que le rideau descende)."""
        d = self.door
        deadline = pulse_at + d.close_confirm_timeout_s
        blocked_since: Optional[float] = None
        last_state = None
        while self._clock() < deadline:
            if self._cancelled():
                return False
            obs = self.close_observer.observe()
            now = self._clock()
            if obs.state is not last_state:
                self._log("close_vision", state=obs.state.value, detail=obs.detail)
                last_state = obs.state
            if obs.state is PassageState.BLOCKED:
                if blocked_since is None:
                    blocked_since = now
                if (now - blocked_since) >= d.closed_stable_s and (now - pulse_at) >= d.close_time_s:
                    return True
            else:
                blocked_since = None
            self._sleep(d.close_vision.period_s)
        return False

    def close_and_confirm(self) -> PassageResult:
        """À appeler quand Spot est arrêté en zone X, après la porte (fin de la région)."""
        d = self.door
        if not d.closes_on_command:
            return PassageResult(Outcome.CLOSE_NOT_REQUIRED, d.door_id, 0,
                                 detail="la porte se referme seule")
        self._log("zone_x", msg=f"arrivé en zone X (porte {d.door_id}) : je peux fermer la porte")
        try:
            status = self.transport.status(d)
        except DoorTransportError as exc:
            self._log("close_alert", outcome=Outcome.MODULE_UNREACHABLE.value, error=str(exc),
                      msg="porte laissée ouverte : module injoignable")
            return PassageResult(Outcome.MODULE_UNREACHABLE, d.door_id, 0, detail=str(exc))
        if status.close_enabled is False:
            self._log("close_alert", outcome=Outcome.CLOSE_NOT_CONFIRMED.value,
                      msg="module non réglé pour la fermeture (set close 1)")
            return PassageResult(Outcome.CLOSE_NOT_CONFIRMED, d.door_id, 0,
                                 detail="close_disabled : régler le module (set close 1)")
        if not self._wait_clear_behind():
            self._log("close_alert", outcome=Outcome.CLOSE_SKIPPED_PASSAGE_OCCUPIED.value,
                      msg="porte laissée ouverte : passage occupé derrière Spot")
            return PassageResult(Outcome.CLOSE_SKIPPED_PASSAGE_OCCUPIED, d.door_id, 0,
                                 detail="passage non libre derrière Spot")
        self._log("close_clear", msg="passage libre derrière Spot")
        attempts = 0
        errors = 0
        detail = ""
        while attempts < d.max_close_attempts:
            if self._cancelled():
                return PassageResult(Outcome.CANCELLED, d.door_id, attempts)
            attempts += 1
            try:
                ack = self.transport.close(d)
            except DoorTransportError as exc:
                errors += 1
                detail = str(exc)
                self._log("close_pulse_failed", attempt=attempts, error=str(exc))
                continue
            if ack.reason in CLOSE_RETRY_REASONS:
                self._log("close_pulse_refused", attempt=attempts, reason=ack.reason)
                self._sleep(2.0)
                continue
            if ack.reason not in ACCEPTED_REASONS:
                self._log("close_alert", outcome=Outcome.CLOSE_NOT_CONFIRMED.value,
                          reason=ack.reason, msg="fermeture refusée par le module")
                return PassageResult(Outcome.CLOSE_NOT_CONFIRMED, d.door_id, attempts,
                                     detail=f"refus du module : {ack.reason}")
            pulse_at = self._clock()
            self.last_close_at = pulse_at
            self._log("close_pulse_ack", attempt=attempts, pulsed=ack.pulsed, reason=ack.reason,
                      op_id=ack.op_id)
            if self._wait_closed(pulse_at):
                elapsed = self._clock() - pulse_at
                self._log("door_closed", attempt=attempts, seconds_since_close_pulse=round(elapsed, 2))
                return PassageResult(Outcome.DOOR_CLOSED, d.door_id, attempts, elapsed)
            detail = f"porte non vue fermée {d.close_confirm_timeout_s:.0f} s après l'impulsion"
            self._log("close_not_seen", attempt=attempts, detail=detail)
        if errors == attempts:
            self._log("close_alert", outcome=Outcome.MODULE_UNREACHABLE.value, error=detail,
                      msg="porte laissée ouverte : module injoignable")
            return PassageResult(Outcome.MODULE_UNREACHABLE, d.door_id, attempts, detail=detail)
        self._log("close_alert", outcome=Outcome.CLOSE_NOT_CONFIRMED.value, detail=detail,
                  msg="porte peut-être restée ouverte : vérification humaine")
        return PassageResult(Outcome.CLOSE_NOT_CONFIRMED, d.door_id, attempts,
                             self._clock() - self.last_close_at if self.last_close_at else None,
                             detail)
