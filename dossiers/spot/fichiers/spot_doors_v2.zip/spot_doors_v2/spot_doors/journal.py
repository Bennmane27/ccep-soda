"""Journal d'événements JSON Lines + compteurs par porte.

Chaque ligne est un objet JSON horodaté : facile à relire, à agréger ou à envoyer plus
tard vers un tableau de bord. Les secrets ne sont jamais journalisés.
"""
from __future__ import annotations

import json
import logging
import threading
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Optional

LOGGER = logging.getLogger(__name__)


class Journal:
    def __init__(self, log_dir: Optional[Path] = None):
        self._lock = threading.Lock()
        self._path: Optional[Path] = None
        self.counters: Dict[str, Counter] = defaultdict(Counter)
        if log_dir is not None:
            try:
                log_dir.mkdir(parents=True, exist_ok=True)
                self._path = log_dir / f"doors_{time.strftime('%Y%m%d')}.jsonl"
            except OSError as exc:
                LOGGER.warning("Journal fichier indisponible (%s), journal console seulement", exc)

    def event(self, door_id: str, event: str, **fields) -> None:
        record = {"ts": round(time.time(), 3), "door_id": door_id, "event": event, **fields}
        self.counters[door_id][event] += 1
        line = json.dumps(record, ensure_ascii=False, default=str)
        LOGGER.info(line)
        if self._path is None:
            return
        with self._lock:
            try:
                with self._path.open("a", encoding="utf-8") as fh:
                    fh.write(line + "\n")
            except OSError as exc:
                LOGGER.warning("Écriture du journal impossible : %s", exc)
