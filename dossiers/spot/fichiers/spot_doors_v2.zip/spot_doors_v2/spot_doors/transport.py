"""Communication avec les modules de porte.

`DoorTransport` est l'interface ; `HttpDoorTransport` parle au firmware door_node
(Wi-Fi/HTTP). Un autre transport (BLE via la chaîne espagnole, automate du site,
contrôle d'accès existant) peut être ajouté sans toucher à la logique de passage.
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from typing import Optional, Protocol

import requests

from .config import DoorConfig

LOGGER = logging.getLogger(__name__)


class DoorTransportError(RuntimeError):
    """Le module de porte n'a pas répondu correctement."""


@dataclass
class OpenAck:
    """Accusé de réception d'une demande d'impulsion (ouverture K1 ou fermeture K2).

    Ne prouve PAS que la porte a bougé : la confirmation vient des caméras ou d'un contact.
    """
    op_id: str
    pulsed: bool
    reason: str


PulseAck = OpenAck

# Réponses 409 du module qui sont des refus explicites (pas une erreur réseau) :
EXPLICIT_REFUSALS = {"close_disabled", "too_soon_after_open", "too_soon_after_close"}


@dataclass
class NodeStatus:
    door_id: str
    fw: str
    mode: str
    rssi: int
    pulse_count: int
    ms_since_last_pulse: int
    open_input: str
    close_enabled: Optional[bool] = None   # None : firmware antérieur à la fermeture commandée
    close_count: int = 0


class DoorTransport(Protocol):
    def status(self, door: DoorConfig) -> NodeStatus: ...
    def open(self, door: DoorConfig, op_id: Optional[str] = None) -> OpenAck: ...
    def close(self, door: DoorConfig, op_id: Optional[str] = None) -> OpenAck: ...


class HttpDoorTransport:
    def __init__(self, session: Optional[requests.Session] = None):
        self._session = session or requests.Session()

    def _request(self, door: DoorConfig, method: str, path: str, **kwargs) -> dict:
        url = f"{door.base_url}{path}"
        headers = {"Authorization": f"Bearer {door.token()}"}
        last_exc: Optional[Exception] = None
        for attempt in range(1, door.request_retries + 2):
            try:
                resp = self._session.request(method, url, headers=headers,
                                             timeout=door.request_timeout_s, **kwargs)
            except requests.RequestException as exc:
                last_exc = exc
                LOGGER.warning("%s %s tentative %d : %s", method, url, attempt, exc)
                continue
            if resp.status_code == 401:
                raise DoorTransportError(f"{door.door_id}: jeton refusé par le module")
            if resp.status_code == 409:
                try:
                    data = resp.json()
                except ValueError:
                    data = {}
                if data.get("reason") in EXPLICIT_REFUSALS:
                    return data  # refus explicite : le contrôleur décide
                raise DoorTransportError(f"{door.door_id}: le module répond pour une autre porte")
            if resp.status_code != 200:
                last_exc = DoorTransportError(f"HTTP {resp.status_code}")
                continue
            try:
                return resp.json()
            except ValueError as exc:
                raise DoorTransportError(f"{door.door_id}: réponse illisible") from exc
        raise DoorTransportError(f"{door.door_id}: module injoignable ({last_exc})")

    def status(self, door: DoorConfig) -> NodeStatus:
        data = self._request(door, "GET", "/status")
        if data.get("door_id") != door.door_id:
            raise DoorTransportError(
                f"Le module à {door.host} annonce {data.get('door_id')!r}, attendu {door.door_id!r}")
        if data.get("mode") != "auto":
            raise DoorTransportError(f"{door.door_id}: firmware non prévu pour le mode auto")
        return NodeStatus(
            door_id=data["door_id"], fw=data.get("fw", "?"), mode=data["mode"],
            rssi=int(data.get("rssi", 0)), pulse_count=int(data.get("pulse_count", 0)),
            ms_since_last_pulse=int(data.get("ms_since_last_pulse", -1)),
            open_input=data.get("open_input", "not_configured"),
            close_enabled=data.get("close_enabled"),
            close_count=int(data.get("close_count", 0)))

    def _pulse(self, door: DoorConfig, path: str, op_id: Optional[str]) -> OpenAck:
        op_id = op_id or uuid.uuid4().hex[:16]
        # La même op_id est renvoyée à chaque nouvelle tentative réseau : le module ne
        # déclenche qu'une impulsion même si la première réponse s'est perdue.
        data = self._request(door, "POST", path,
                             params={"op_id": op_id, "door_id": door.door_id})
        if data.get("door_id") != door.door_id:
            raise DoorTransportError(f"{door.door_id}: accusé reçu d'une autre porte")
        return OpenAck(op_id=op_id, pulsed=bool(data.get("pulsed")),
                       reason=str(data.get("reason", "")))

    def open(self, door: DoorConfig, op_id: Optional[str] = None) -> OpenAck:
        """Impulsion K1 en parallèle du bouton vert."""
        return self._pulse(door, "/open", op_id)

    def close(self, door: DoorConfig, op_id: Optional[str] = None) -> OpenAck:
        """Impulsion K2 en parallèle du bouton de fermeture (portes à fermeture commandée).

        Raison "close_disabled" : le module n'est pas réglé pour fermer (set close 1).
        """
        return self._pulse(door, "/close", op_id)
