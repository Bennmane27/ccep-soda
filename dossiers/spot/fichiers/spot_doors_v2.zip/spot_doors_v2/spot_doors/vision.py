"""Vérification du passage avec les caméras de profondeur de Spot.

Principe (pensé pour un rideau souple en partie transparent) :
on contrôle une boîte 3D, dans le repère "body" du robot arrêté au point d'attente,
qui couvre l'ouverture de la porte : largeur de passage, du sol jusqu'à la hauteur
libre exigée, et une tranche autour du plan de porte.

- Porte fermée ou à mi-hauteur : la barre basse et les parties opaques du rideau
  renvoient des points dans la boîte -> ENCOMBRE.
- Porte ouverte au-dessus de la hauteur exigée : la boîte est vide, alors que le reste
  de la scène renvoie assez de points valides -> LIBRE.
- Trop peu de points valides, image trop ancienne, erreur : INCONNU (jamais LIBRE).

La partie transparente seule peut ne renvoyer aucun point : c'est pour cela que la
boîte part du sol et que l'on exige la disparition de la barre basse.

Fermeture commandée : en zone X, la porte est DERRIÈRE Spot. On réutilise le même
gabarit avec la caméra de profondeur arrière (source "back_depth") et un plan de porte
à x négatif (DoorConfig.close_vision). LIBRE = personne ni rien sous la porte (on peut
fermer) ; ENCOMBRÉ stable après la durée de descente = rideau en bas (porte fermée). Les seuils sont
à calibrer avec des images enregistrées sur chaque porte (voir cli.py collect).
"""
from __future__ import annotations

import enum
import logging
import time
from dataclasses import dataclass
from typing import Callable, Iterable, List, Optional, Sequence

import numpy as np

from .config import VisionConfig

LOGGER = logging.getLogger(__name__)


class PassageState(enum.Enum):
    FREE = "libre"
    BLOCKED = "encombre"
    UNKNOWN = "inconnu"


@dataclass
class Observation:
    state: PassageState
    timestamp: float
    points_in_box: int
    valid_points: int
    detail: str = ""


def classify_points(points_body: np.ndarray, cfg: VisionConfig) -> Observation:
    """Classe un nuage de points (N x 3, repère body, mètres). Fonction pure, testable."""
    now = time.time()
    if points_body is None or len(points_body) == 0:
        return Observation(PassageState.UNKNOWN, now, 0, 0, "aucun point")
    pts = np.asarray(points_body, dtype=float)
    valid = int(len(pts))
    x, y, z = pts[:, 0], pts[:, 1], pts[:, 2]
    in_box = (
        (np.abs(x - cfg.door_plane_x_m) <= cfg.plane_tolerance_m)
        & (np.abs(y) <= cfg.half_width_m)
        & (z >= cfg.floor_z_m + 0.03)                  # ignore le sol lui-même
        & (z <= cfg.floor_z_m + cfg.clear_height_m)
    )
    n_box = int(np.count_nonzero(in_box))
    if valid < cfg.min_valid_points:
        return Observation(PassageState.UNKNOWN, now, n_box, valid, "trop peu de points valides")
    if n_box > cfg.max_points_in_box:
        return Observation(PassageState.BLOCKED, now, n_box, valid, "objet dans le gabarit")
    return Observation(PassageState.FREE, now, n_box, valid, "gabarit vide")


class StabilityFilter:
    """Ne déclare LIBRE que si toutes les observations sont LIBRE depuis `stable_s`."""

    def __init__(self, stable_s: float, clock: Callable[[], float] = time.monotonic):
        self._stable_s = stable_s
        self._clock = clock
        self._free_since: Optional[float] = None

    def reset(self) -> None:
        self._free_since = None

    def update(self, obs: Observation) -> bool:
        now = self._clock()
        if obs.state is PassageState.FREE:
            if self._free_since is None:
                self._free_since = now
            return (now - self._free_since) >= self._stable_s
        self._free_since = None
        return False


class PassageObserver:
    """Interface utilisée par le contrôleur : une observation récente à la demande."""

    def observe(self) -> Observation:  # pragma: no cover - interface
        raise NotImplementedError


class SpotDepthObserver(PassageObserver):
    """Lit les images de profondeur de Spot et les convertit dans le repère body.

    Les caméras utilisées sont celles de cfg.depth_sources : avant pour l'ouverture
    (frontleft_depth, frontright_depth), arrière pour la fermeture (back_depth).
    """

    def __init__(self, robot, cfg: VisionConfig):
        from bosdyn.client.image import ImageClient  # import tardif : tests sans SDK robot
        self._robot = robot
        self._cfg = cfg
        self._client = robot.ensure_client(ImageClient.default_service_name)

    def observe(self) -> Observation:
        from bosdyn.client.frame_helpers import BODY_FRAME_NAME, get_a_tform_b
        from bosdyn.client.image import depth_image_to_pointcloud
        try:
            responses = self._client.get_image_from_sources(list(self._cfg.depth_sources))
        except Exception as exc:  # réseau, source absente...
            return Observation(PassageState.UNKNOWN, time.time(), 0, 0, f"erreur image : {exc}")
        clouds: List[np.ndarray] = []
        for resp in responses:
            age = self._image_age_s(resp)
            if age is None or age > self._cfg.max_image_age_s:
                return Observation(PassageState.UNKNOWN, time.time(), 0, 0,
                                   f"image trop ancienne ({resp.source.name})")
            pts_sensor = depth_image_to_pointcloud(resp, min_dist=0.2, max_dist=6.0)
            body_tform_sensor = get_a_tform_b(resp.shot.transforms_snapshot, BODY_FRAME_NAME,
                                              resp.shot.frame_name_image_sensor)
            if body_tform_sensor is None or len(pts_sensor) == 0:
                continue
            clouds.append(body_tform_sensor.transform_cloud(pts_sensor))
        if not clouds:
            return Observation(PassageState.UNKNOWN, time.time(), 0, 0, "aucune image exploitable")
        return classify_points(np.vstack(clouds), self._cfg)

    def _image_age_s(self, resp) -> Optional[float]:
        try:
            acq = resp.shot.acquisition_time
            robot_time = acq.seconds + acq.nanos * 1e-9
            local = self._robot.time_sync.get_robot_clock_skew()
            skew = local.seconds + local.nanos * 1e-9 if local is not None else 0.0
            return time.time() - (robot_time - skew)
        except Exception:
            return None


class ScriptedObserver(PassageObserver):
    """Observateur rejoué (tests, simulateur, images enregistrées)."""

    def __init__(self, states: Iterable[PassageState]):
        self._states = list(states)
        self._i = 0

    def observe(self) -> Observation:
        state = self._states[min(self._i, len(self._states) - 1)]
        self._i += 1
        return Observation(state, time.time(), 0, 0, "scripted")


class NodeInputObserver(PassageObserver):
    """Confirmation par le contact "porte ouverte" lu par le module de porte.

    Indique une position mécanique, pas un passage vide : à combiner avec la vision
    si des personnes ou des objets peuvent se trouver sous la porte.
    """

    def __init__(self, transport, door):
        self._transport = transport
        self._door = door

    def observe(self) -> Observation:
        try:
            status = self._transport.status(self._door)
        except Exception as exc:
            return Observation(PassageState.UNKNOWN, time.time(), 0, 0, f"module : {exc}")
        if status.open_input == "open_contact_active":
            return Observation(PassageState.FREE, time.time(), 0, 0, "contact ouvert actif")
        if status.open_input == "open_contact_inactive":
            return Observation(PassageState.BLOCKED, time.time(), 0, 0, "contact ouvert inactif")
        return Observation(PassageState.UNKNOWN, time.time(), 0, 0, "contact non configuré")


class AllOfObserver(PassageObserver):
    """LIBRE seulement si tous les observateurs disent LIBRE ; INCONNU l'emporte sur ENCOMBRE.

    Avec require_all_blocked=True (contrôle « porte fermée »), ENCOMBRÉ n'est retenu que si
    tous les observateurs le voient ; un désaccord donne INCONNU.
    """

    def __init__(self, observers: Sequence[PassageObserver], require_all_blocked: bool = False):
        self._observers = list(observers)
        self._require_all_blocked = require_all_blocked

    def observe(self) -> Observation:
        results = [o.observe() for o in self._observers]
        states = {r.state for r in results}
        if self._require_all_blocked and states != {PassageState.FREE}:
            state = PassageState.BLOCKED if states == {PassageState.BLOCKED} else PassageState.UNKNOWN
        elif PassageState.UNKNOWN in states:
            state = PassageState.UNKNOWN
        elif PassageState.BLOCKED in states:
            state = PassageState.BLOCKED
        else:
            state = PassageState.FREE
        return Observation(state, time.time(), sum(r.points_in_box for r in results),
                           sum(r.valid_points for r in results),
                           " | ".join(r.detail for r in results))
