"""Fermeture commandée : portes qui ne se referment pas seules (relais K2, zone X)."""
import pytest

from spot_doors.config import ConfigError, DoorConfig, VisionConfig, load_site_config
from spot_doors.controller import DoorPassageController, Outcome
from spot_doors.journal import Journal
from spot_doors.transport import DoorTransportError, NodeStatus, OpenAck
from spot_doors.vision import ScriptedObserver, PassageState as S


class FakeClock:
    def __init__(self):
        self.t = 100.0

    def __call__(self):
        return self.t

    def sleep(self, dt):
        self.t += dt


class FakeTransport:
    def __init__(self, reachable=True, close_enabled=True, close_reason="pulsed"):
        self.reachable = reachable
        self.close_enabled = close_enabled
        self.close_reason = close_reason
        self.opens = 0
        self.closes = 0

    def status(self, door):
        if not self.reachable:
            raise DoorTransportError("injoignable")
        return NodeStatus(door.door_id, "test", "auto", -50, self.opens, -1, "not_configured",
                          close_enabled=self.close_enabled, close_count=self.closes)

    def open(self, door, op_id=None):
        self.opens += 1
        return OpenAck("op", True, "pulsed")

    def close(self, door, op_id=None):
        if not self.reachable:
            raise DoorTransportError("injoignable")
        self.closes += 1
        return OpenAck(f"c{self.closes}", self.close_reason == "pulsed", self.close_reason)


VISION = VisionConfig(stable_free_s=1.0, period_s=0.2)


def door(**kw):
    base = dict(door_id="P06", name="test", host="127.0.0.1", close_mode="commande",
                close_time_s=4.0, closed_stable_s=1.0, clear_before_close_timeout_s=5.0,
                hold_open_s=25.0, crossing_time_s=8.0, safety_margin_s=5.0, vision=VISION,
                close_vision=VisionConfig(depth_sources=("back_depth",), door_plane_x_m=-1.8,
                                          stable_free_s=1.0, period_s=0.2))
    base.update(kw)
    return DoorConfig(**base)


def make(d, transport, close_states):
    clock = FakeClock()
    ctrl = DoorPassageController(d, transport, ScriptedObserver([S.FREE] * 100), Journal(None),
                                 sleep=clock.sleep, clock=clock,
                                 close_observer=ScriptedObserver(close_states))
    return ctrl, clock


def test_close_confirmed_after_descent():
    # Passage libre derrière Spot, puis le rideau descend (encombré stable) : porte fermée.
    states = [S.FREE] * 8 + [S.FREE] * 8 + [S.BLOCKED] * 60
    t = FakeTransport()
    ctrl, clock = make(door(), t, states)
    res = ctrl.close_and_confirm()
    assert res.outcome is Outcome.DOOR_CLOSED and res.ok
    assert t.closes == 1 and res.attempts == 1
    assert res.seconds_since_pulse >= 4.0   # jamais confirmé avant la durée de descente


def test_blocked_too_early_waits_for_descent_time():
    # Encombré dès l'impulsion (rideau qui passe devant la caméra) : on attend close_time_s.
    states = [S.FREE] * 6 + [S.BLOCKED] * 100
    ctrl, _ = make(door(close_time_s=6.0), FakeTransport(), states)
    res = ctrl.close_and_confirm()
    assert res.outcome is Outcome.DOOR_CLOSED and res.seconds_since_pulse >= 6.0


def test_occupied_passage_leaves_door_open_without_pulse():
    t = FakeTransport()
    ctrl, _ = make(door(), t, [S.BLOCKED] * 1000)
    res = ctrl.close_and_confirm()
    assert res.outcome is Outcome.CLOSE_SKIPPED_PASSAGE_OCCUPIED and not res.ok
    assert t.closes == 0


def test_unknown_vision_never_allows_closing():
    t = FakeTransport()
    ctrl, _ = make(door(), t, [S.UNKNOWN] * 1000)
    assert ctrl.close_and_confirm().outcome is Outcome.CLOSE_SKIPPED_PASSAGE_OCCUPIED
    assert t.closes == 0


def test_door_that_does_not_descend_gets_two_pulses_then_alert():
    t = FakeTransport()
    ctrl, _ = make(door(), t, [S.FREE] * 1000)   # le rideau ne descend jamais
    res = ctrl.close_and_confirm()
    assert res.outcome is Outcome.CLOSE_NOT_CONFIRMED and t.closes == 2 and res.attempts == 2


def test_module_unreachable():
    t = FakeTransport(reachable=False)
    ctrl, _ = make(door(), t, [S.FREE] * 100)
    res = ctrl.close_and_confirm()
    assert res.outcome is Outcome.MODULE_UNREACHABLE and t.closes == 0


def test_module_not_configured_for_closing():
    t = FakeTransport(close_enabled=False)
    ctrl, _ = make(door(), t, [S.FREE] * 100)
    res = ctrl.close_and_confirm()
    assert res.outcome is Outcome.CLOSE_NOT_CONFIRMED and t.closes == 0
    assert "close" in res.detail


def test_auto_door_needs_no_close():
    t = FakeTransport()
    ctrl, _ = make(door(close_mode="auto"), t, [S.FREE] * 100)
    res = ctrl.close_and_confirm()
    assert res.outcome is Outcome.CLOSE_NOT_REQUIRED and t.closes == 0


def test_command_door_always_has_time_to_cross():
    # Ouverture très lente : refusée pour une porte auto, acceptée pour une porte commande
    # (elle ne redescend pas seule).
    from tests.test_controller import FakeTransport as OpenTransport
    slow = [S.BLOCKED] * 100 + [S.FREE] * 50
    clock = FakeClock()
    d = door(open_timeout_s=40.0, hold_open_s=10.0)
    ctrl = DoorPassageController(d, OpenTransport(), ScriptedObserver(slow), Journal(None),
                                 sleep=clock.sleep, clock=clock)
    assert ctrl.open_and_confirm().ok
    assert ctrl.ensure_time_to_cross().ok


def test_config_validation(tmp_path):
    p = tmp_path / "d.yaml"
    p.write_text("doors:\n  - door_id: P06\n    name: x\n    host: h\n    close_mode: commande\n"
                 "    hold_open_s: 5\n", encoding="utf-8")
    d = load_site_config(p).door("P06")   # hold_open_s court accepté : la porte ne se referme pas seule
    assert d.close_confirm_timeout_s == pytest.approx(d.close_time_s + 5.0)
    assert d.close_vision.depth_sources == ("back_depth",) and d.close_vision.door_plane_x_m < 0
    p.write_text("doors:\n  - door_id: P06\n    name: x\n    host: h\n    close_mode: manuel\n",
                 encoding="utf-8")
    with pytest.raises(ConfigError):
        load_site_config(p)
    p.write_text("doors:\n  - door_id: P06\n    name: x\n    host: h\n    close_mode: commande\n"
                 "    close_vision:\n      door_plane_x_m: 1.8\n", encoding="utf-8")
    with pytest.raises(ConfigError):
        load_site_config(p)
