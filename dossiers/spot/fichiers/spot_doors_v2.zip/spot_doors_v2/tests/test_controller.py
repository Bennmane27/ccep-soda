"""Logique de passage : cas nominaux et dégradés, sans robot ni réseau."""
import pytest

from spot_doors.config import DoorConfig, VisionConfig
from spot_doors.controller import DoorPassageController, Outcome
from spot_doors.journal import Journal
from spot_doors.transport import DoorTransportError, NodeStatus, OpenAck
from spot_doors.vision import ScriptedObserver, PassageState as S


class FakeClock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t

    def sleep(self, dt):
        self.t += dt


class FakeTransport:
    def __init__(self, reachable=True, open_fails=0, reason="pulsed"):
        self.reachable = reachable
        self.open_fails = open_fails
        self.reason = reason
        self.opens = 0

    def status(self, door):
        if not self.reachable:
            raise DoorTransportError("injoignable")
        return NodeStatus(door.door_id, "test", "auto", -50, self.opens, -1, "not_configured")

    def open(self, door, op_id=None):
        self.opens += 1
        if self.open_fails > 0:
            self.open_fails -= 1
            raise DoorTransportError("perte réseau")
        return OpenAck("op", True, self.reason)


def door(**kw):
    vision = VisionConfig(stable_free_s=1.0, period_s=0.2)
    base = dict(door_id="P01", name="test", host="127.0.0.1", open_timeout_s=10.0,
                hold_open_s=25.0, crossing_time_s=8.0, safety_margin_s=5.0,
                max_open_attempts=2, vision=vision)
    base.update(kw)
    return DoorConfig(**base)


def make(d, transport, states):
    clock = FakeClock()
    ctrl = DoorPassageController(d, transport, ScriptedObserver(states), Journal(None),
                                 sleep=clock.sleep, clock=clock)
    return ctrl, clock


def test_nominal_opening_confirmed():
    states = [S.BLOCKED] * 10 + [S.FREE] * 20
    ctrl, clock = make(door(), FakeTransport(), states)
    res = ctrl.open_and_confirm()
    assert res.ok and res.attempts == 1
    assert ctrl.ensure_time_to_cross().ok


def test_flicker_requires_stability():
    # Un seul "libre" isolé ne suffit pas.
    states = [S.BLOCKED, S.FREE, S.BLOCKED, S.FREE, S.UNKNOWN] * 6 + [S.FREE] * 10
    ctrl, clock = make(door(), FakeTransport(), states)
    res = ctrl.open_and_confirm()
    assert res.ok
    assert clock.t >= 6.0  # n'a pas validé pendant la phase instable


def test_unknown_vision_never_confirms():
    ctrl, _ = make(door(), FakeTransport(), [S.UNKNOWN] * 1000)
    res = ctrl.open_and_confirm()
    assert not res.ok and res.outcome is Outcome.OPEN_TIMEOUT and res.attempts == 2


def test_module_unreachable_fails_without_pulse():
    t = FakeTransport(reachable=False)
    ctrl, _ = make(door(), t, [S.FREE] * 100)
    res = ctrl.open_and_confirm()
    assert res.outcome is Outcome.MODULE_UNREACHABLE and t.opens == 0


def test_lost_pulse_is_retried_once():
    t = FakeTransport(open_fails=1)
    ctrl, _ = make(door(), t, [S.FREE] * 100)
    res = ctrl.open_and_confirm()
    assert res.ok and res.attempts == 2 and t.opens == 2


def test_refused_pulse_reason_fails():
    ctrl, _ = make(door(), FakeTransport(reason="weird"), [S.FREE] * 100)
    assert not ctrl.open_and_confirm().ok


def test_slow_opening_leaves_no_time_to_cross():
    # Libre seulement après 14 s : 14 + 8 + 5 > 25 -> refus de passage.
    states = [S.BLOCKED] * 70 + [S.FREE] * 50
    ctrl, _ = make(door(open_timeout_s=30.0), FakeTransport(), states)
    assert ctrl.open_and_confirm().ok
    res = ctrl.ensure_time_to_cross()
    assert res.outcome is Outcome.NOT_ENOUGH_TIME


def test_repulse_when_timer_reset_is_proven():
    states = [S.BLOCKED] * 70 + [S.FREE] * 100
    t = FakeTransport()
    ctrl, _ = make(door(open_timeout_s=30.0, repulse_resets_timer=True), t, states)
    assert ctrl.open_and_confirm().ok
    assert ctrl.ensure_time_to_cross().ok
    assert t.opens == 2


def test_second_pulse_does_not_extend_time_without_proof():
    # Passage encombré pendant tout le premier délai : 2e impulsion, porte déjà ouverte.
    # Sans preuve que l'impulsion relance la temporisation, le temps restant se compte
    # depuis la 1re impulsion : 14 + 8 + 5 > 25 -> refus, au lieu d'un passage sous une
    # porte qui redescend.
    states = [S.BLOCKED] * 65 + [S.FREE] * 50
    t = FakeTransport()
    ctrl, _ = make(door(open_timeout_s=13.0), t, states)
    assert ctrl.open_and_confirm().ok and t.opens == 2
    assert ctrl.ensure_time_to_cross().outcome is Outcome.NOT_ENOUGH_TIME


def test_invalid_timing_rejected_by_config(tmp_path):
    from spot_doors.config import ConfigError, load_site_config
    p = tmp_path / "d.yaml"
    p.write_text("doors:\n  - {door_id: P01, name: x, host: h, hold_open_s: 10, crossing_time_s: 8}\n")
    with pytest.raises(ConfigError):
        load_site_config(p)
