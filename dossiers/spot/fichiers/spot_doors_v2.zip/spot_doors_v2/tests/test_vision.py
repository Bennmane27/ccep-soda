"""Classification géométrique du passage sur des nuages de points synthétiques."""
import numpy as np

from spot_doors.config import VisionConfig
from spot_doors.vision import PassageState, classify_points

CFG = VisionConfig()
RNG = np.random.default_rng(0)


def background(n=4000):
    # Couloir au-delà de la porte (x 2.5..5 m) + sol devant : points valides hors gabarit.
    far = np.column_stack([RNG.uniform(2.5, 5.0, n), RNG.uniform(-1.5, 1.5, n),
                           RNG.uniform(CFG.floor_z_m, 1.0, n)])
    floor = np.column_stack([RNG.uniform(0.5, 4.0, n), RNG.uniform(-1.0, 1.0, n),
                             np.full(n, CFG.floor_z_m)])
    return np.vstack([far, floor])


def bottom_bar(z):
    # Barre basse opaque du rideau, dans le plan de porte, à la hauteur z (repère body).
    n = 600
    return np.column_stack([RNG.normal(CFG.door_plane_x_m, 0.02, n), RNG.uniform(-1.0, 1.0, n),
                            RNG.normal(z, 0.03, n)])


def test_open_door_is_free():
    pts = np.vstack([background(), bottom_bar(CFG.floor_z_m + 2.5)])  # barre en haut
    assert classify_points(pts, CFG).state is PassageState.FREE


def test_closed_door_is_blocked():
    pts = np.vstack([background(), bottom_bar(CFG.floor_z_m + 0.05)])
    assert classify_points(pts, CFG).state is PassageState.BLOCKED


def test_half_open_door_is_blocked():
    pts = np.vstack([background(), bottom_bar(CFG.floor_z_m + 0.6)])
    assert classify_points(pts, CFG).state is PassageState.BLOCKED


def test_masked_camera_is_unknown():
    pts = background(200)
    assert classify_points(pts, CFG).state is PassageState.UNKNOWN


def test_person_under_door_is_blocked():
    person = np.column_stack([RNG.normal(CFG.door_plane_x_m, 0.1, 800), RNG.normal(0.1, 0.15, 800),
                              RNG.uniform(CFG.floor_z_m, CFG.floor_z_m + 1.7, 800)])
    pts = np.vstack([background(), bottom_bar(CFG.floor_z_m + 2.5), person])
    assert classify_points(pts, CFG).state is PassageState.BLOCKED
