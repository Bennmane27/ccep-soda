"""Chaîne réseau réelle contre le simulateur : transport HTTP, firmware simulé, et
utilitaire officiel Boston Dynamics (celui de la fonction native "access controlled doors")."""
import json
import socket

import pytest

from door_simulator import SimulatedDoor, serve
from spot_doors.config import DoorConfig, VisionConfig
from spot_doors.controller import DoorPassageController
from spot_doors.journal import Journal
from spot_doors.transport import DoorTransportError, HttpDoorTransport
from spot_doors.vision import NodeInputObserver

TOKEN = "jeton-de-test-0123456789"


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


@pytest.fixture
def sim(monkeypatch):
    monkeypatch.setenv("SPOT_DOOR_TOKEN", TOKEN)
    port = free_port()
    door_model = SimulatedDoor(open_time_s=0.6, hold_s=6.0, close_time_s=0.5)
    srv = serve("P01", TOKEN, port, door_model, cooldown_s=1.0)
    yield port, door_model
    srv.shutdown()


def cfg(port, **kw):
    base = dict(door_id="P01", name="sim", host="127.0.0.1", port=port, open_timeout_s=3.0,
                hold_open_s=6.0, crossing_time_s=2.0, safety_margin_s=1.0,
                vision=VisionConfig(method="input", stable_free_s=0.3, period_s=0.05))
    base.update(kw)
    return DoorConfig(**base)


def test_status_and_idempotent_open(sim):
    port, model = sim
    t = HttpDoorTransport()
    d = cfg(port)
    assert t.status(d).mode == "auto"
    a1 = t.open(d, op_id="abc")
    a2 = t.open(d, op_id="abc")
    assert a1.pulsed and not a2.pulsed and a2.reason == "duplicate_op_id"


def test_wrong_token_rejected(sim, monkeypatch):
    port, _ = sim
    monkeypatch.setenv("SPOT_DOOR_TOKEN", "mauvais-jeton-0123456789")
    with pytest.raises(DoorTransportError):
        HttpDoorTransport().status(cfg(port))


def test_wrong_door_rejected(sim):
    port, _ = sim
    with pytest.raises(DoorTransportError):
        HttpDoorTransport().status(cfg(port, door_id="P02"))


def test_full_passage_with_open_contact(sim):
    port, _ = sim
    d = cfg(port)
    t = HttpDoorTransport()
    ctrl = DoorPassageController(d, t, NodeInputObserver(t, d), Journal(None))
    res = ctrl.open_and_confirm()
    assert res.ok
    assert ctrl.ensure_time_to_cross().ok


def test_stuck_door_never_confirmed(sim):
    port, model = sim
    model.stuck = True
    d = cfg(port, open_timeout_s=1.0)
    t = HttpDoorTransport()
    res = DoorPassageController(d, t, NodeInputObserver(t, d), Journal(None)).open_and_confirm()
    assert not res.ok


def test_boston_dynamics_native_util_drives_module(sim, tmp_path):
    """La configuration native fournie est exécutée par le code du SDK Boston Dynamics."""
    from bosdyn.client.access_controlled_door_util import door_action
    port, model = sim
    calls = json.loads(open(__import__("pathlib").Path(__file__).resolve().parents[1] / "config" / "spot_native_access_control.json").read())
    for c in calls:
        c["route"] = "lo"  # sur PC : interface réseau locale (sur le robot : WIFI)
        c["request_data"]["headers"]["Authorization"] = f"Bearer {TOKEN}"
    door_id = f"127.0.0.1:{port}"  # en natif, le DoorID enregistré est l'adresse du module
    assert door_action(calls, door_id, ["OPEN"], is_robot=False) == {}
    assert model.pulse_at is not None
    # Porte qui se referme seule : le module refuse la fermeture (409 close_disabled), sans
    # impulsion. Pour ces portes, utiliser spot_native_access_control_portes_auto.json.
    err = door_action(calls, door_id, ["CLOSE"], is_robot=False)
    assert err["api_error"]["status_code"] == 409 and model.close_at is None


@pytest.fixture
def sim_cmd(monkeypatch):
    monkeypatch.setenv("SPOT_DOOR_TOKEN", TOKEN)
    port = free_port()
    door_model = SimulatedDoor(open_time_s=0.6, hold_s=1.0, close_time_s=0.8, close_mode="commande")
    srv = serve("P06", TOKEN, port, door_model, cooldown_s=1.0)
    yield port, door_model
    srv.shutdown()


def test_command_door_open_then_close_end_to_end(sim_cmd):
    """Porte à fermeture commandée : ouverture, elle reste ouverte, fermeture K2 confirmée."""
    import time
    port, model = sim_cmd
    d = cfg(port, door_id="P06", close_mode="commande", close_time_s=0.8, closed_stable_s=0.3,
            close_confirm_timeout_s=3.0, clear_before_close_timeout_s=3.0, hold_open_s=1.0,
            close_vision=VisionConfig(method="input", stable_free_s=0.3, period_s=0.05))
    t = HttpDoorTransport()
    obs = NodeInputObserver(t, d)
    ctrl = DoorPassageController(d, t, obs, Journal(None), close_observer=obs)
    assert ctrl.open_and_confirm().ok
    assert ctrl.ensure_time_to_cross().ok
    time.sleep(2.0)                      # au-delà de hold_s : une porte auto serait redescendue
    assert model.position() == 1.0
    assert t.status(d).close_enabled is True
    res = ctrl.close_and_confirm()
    assert res.ok, res
    assert model.position() == 0.0
    st = t.status(d)
    assert st.close_count == 1 and st.pulse_count == 1
    # Rejeu de la même opération de fermeture : pas de seconde impulsion.
    a1 = t.close(d, op_id="z1")
    a2 = t.close(d, op_id="z1")
    assert not a2.pulsed and a2.reason == "duplicate_op_id"


def test_close_refused_on_auto_door(sim):
    port, model = sim
    d = cfg(port)
    ack = HttpDoorTransport().close(d)
    assert not ack.pulsed and ack.reason == "close_disabled" and model.close_at is None


def test_close_too_soon_after_open(sim_cmd):
    port, model = sim_cmd
    d = cfg(port, door_id="P06", close_mode="commande", hold_open_s=1.0)
    t = HttpDoorTransport()
    assert t.open(d).pulsed
    ack = t.close(d)
    assert ack.reason == "too_soon_after_open" and not ack.pulsed


def test_native_util_closes_command_door(sim_cmd):
    """Fonction native de Spot : sur une porte à fermeture commandée, CLOSE envoie K2."""
    import time
    from bosdyn.client.access_controlled_door_util import door_action
    port, model = sim_cmd
    calls = json.loads(open(__import__("pathlib").Path(__file__).resolve().parents[1] / "config" / "spot_native_access_control.json").read())
    for c in calls:
        c["route"] = "lo"
        c["request_data"]["headers"]["Authorization"] = f"Bearer {TOKEN}"
    door_id = f"127.0.0.1:{port}"
    assert door_action(calls, door_id, ["OPEN"], is_robot=False) == {}
    time.sleep(2.2)   # verrou ouverture -> fermeture de 2 s
    assert door_action(calls, door_id, ["CLOSE"], is_robot=False) == {}
    assert model.close_at is not None
