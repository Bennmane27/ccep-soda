"""Simulateur du module de porte (même API que firmware/door_node).

Sert à tester le service et la configuration native de Spot sans carte ni porte :
  SPOT_DOOR_TOKEN=... python3 tools/door_simulator.py --door-id P01 --port 8081

Il simule aussi une porte automatique : montée après impulsion, temporisation,
descente, pour rejouer les cas "ouverture lente", "porte bloquée", "module muet".
Avec --close-mode commande, la porte reste ouverte jusqu'à une impulsion de fermeture
(POST /api/v1/close, relais K2), puis descend en --close-time secondes.
"""
from __future__ import annotations

import argparse
import hmac
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse


class SimulatedDoor:
    """Porte rapide simulée.

    close_mode "auto" : montée, maintien `hold_s`, descente seule (porte classique).
    close_mode "commande" : la porte reste ouverte ; elle ne descend qu'après une impulsion
    de fermeture (K2), en `close_time_s`.
    """

    def __init__(self, open_time_s=3.0, hold_s=25.0, close_time_s=3.0, stuck=False,
                 close_mode="auto", close_stuck=False):
        self.open_time_s, self.hold_s, self.close_time_s = open_time_s, hold_s, close_time_s
        self.stuck = stuck                # ne s'ouvre jamais
        self.close_stuck = close_stuck    # ne descend jamais sur commande
        self.close_mode = close_mode
        self.pulse_at = None
        self.close_at = None
        self.pos_at_close = 0.0
        self.lock = threading.Lock()

    def _rise(self, now) -> float:
        if self.pulse_at is None or self.stuck:
            return 0.0
        t = now - self.pulse_at
        if t < self.open_time_s:
            return t / self.open_time_s
        if self.close_mode == "commande":
            return 1.0
        if t < self.open_time_s + self.hold_s:
            return 1.0
        t -= self.open_time_s + self.hold_s
        return max(0.0, 1.0 - t / self.close_time_s)

    def pulse(self):
        with self.lock:
            # Hypothèse simulée : une impulsion pendant l'ouverture relance la temporisation.
            self.pulse_at = time.monotonic()
            self.close_at = None

    def close(self):
        with self.lock:
            now = time.monotonic()
            if self.close_stuck:
                return
            self.pos_at_close = self._rise(now) if self.close_at is None else self._position(now)
            self.close_at = now

    def _position(self, now) -> float:
        if self.close_at is None:
            return self._rise(now)
        t = now - self.close_at
        return max(0.0, self.pos_at_close - t / self.close_time_s)

    def position(self) -> float:
        """0.0 = fermée, 1.0 = ouverte."""
        with self.lock:
            return self._position(time.monotonic())


def make_handler(door_id: str, token: str, door: SimulatedDoor, cooldown_s: float):
    state = {"count": 0, "last_pulse": None, "close_count": 0, "last_close": None,
             "last_op": None, "last_op_t": 0.0}
    close_enabled = door.close_mode == "commande"
    interlock_s = 2.0

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):  # journal compact
            print(f"[sim {door_id}] " + fmt % args)

        def _json(self, code, body):
            data = json.dumps(body).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _auth(self) -> bool:
            h = self.headers.get("Authorization", "")
            ok = h.startswith("Bearer ") and hmac.compare_digest(h[7:], token)
            if not ok:
                self._json(401, {"ok": False, "error": "unauthorized"})
            return ok

        def do_GET(self):
            path = urlparse(self.path).path
            if path == "/api/v1/health":
                return self._json(200, {"ok": True, "fw": "simulator"})
            if path == "/api/v1/status":
                if not self._auth():
                    return
                now = time.monotonic()
                last, lastc = state["last_pulse"], state["last_close"]
                pos = door.position()
                return self._json(200, {
                    "ok": True, "door_id": door_id, "fw": "simulator", "mode": "auto",
                    "rssi": -55, "pulse_count": state["count"], "relay_active": False,
                    "ms_since_last_pulse": -1 if last is None else int((now - last) * 1000),
                    "open_input": "open_contact_active" if pos >= 0.999 else "open_contact_inactive",
                    "close_enabled": close_enabled, "close_count": state["close_count"],
                    "ms_since_last_close": -1 if lastc is None else int((now - lastc) * 1000),
                    "sim_position": round(pos, 3)})
            self._json(404, {"ok": False, "error": "not_found"})

        def do_POST(self):
            parsed = urlparse(self.path)
            q = parse_qs(parsed.query)
            length = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(length) if length else b""
            if parsed.path not in ("/api/v1/open", "/api/v1/close"):
                return self._json(404, {"ok": False, "error": "not_found"})
            if not self._auth():
                return
            if "door_id" in q and q["door_id"][0] != door_id:
                return self._json(409, {"ok": False, "error": "door_id_mismatch", "door_id": door_id})
            kind = "close" if parsed.path == "/api/v1/close" else "open"
            op_id = q.get("op_id", [""])[0]
            if not op_id and body:
                try:
                    op_id = str(json.loads(body).get("op_id", ""))
                except ValueError:
                    pass
            key = f"{kind}:{op_id}"
            now = time.monotonic()
            if op_id and key == state["last_op"] and now - state["last_op_t"] < 120:
                return self._json(200, {"ok": True, "pulsed": False, "reason": "duplicate_op_id",
                                        "door_id": door_id, "op_id": op_id})
            last_open, last_close = state["last_pulse"], state["last_close"]
            refused = None
            if kind == "close":
                if not close_enabled:
                    refused = "close_disabled"
                elif last_close is not None and now - last_close < cooldown_s:
                    reason, pulsed = "cooldown", False
                elif last_open is not None and now - last_open < interlock_s:
                    refused = "too_soon_after_open"
                else:
                    door.close()
                    state["close_count"] += 1
                    state["last_close"] = now
                    reason, pulsed = "pulsed", True
            else:
                if last_open is not None and now - last_open < cooldown_s:
                    reason, pulsed = "cooldown", False
                elif last_close is not None and now - last_close < interlock_s:
                    refused = "too_soon_after_close"
                else:
                    door.pulse()
                    state["count"] += 1
                    state["last_pulse"] = now
                    reason, pulsed = "pulsed", True
            relay = "K2" if kind == "close" else "K1"
            if refused:
                return self._json(409, {"ok": False, "pulsed": False, "reason": refused, "relay": relay,
                                        "door_id": door_id, "op_id": op_id})
            if op_id:
                state["last_op"], state["last_op_t"] = key, now
            self._json(200, {"ok": True, "pulsed": pulsed, "reason": reason, "relay": relay,
                             "pulse_ms": 500, "door_id": door_id, "op_id": op_id})

    return Handler


def serve(door_id, token, port, door: SimulatedDoor, cooldown_s=3.0, host="127.0.0.1"):
    srv = ThreadingHTTPServer((host, port), make_handler(door_id, token, door, cooldown_s))
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    return srv


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--door-id", default="P01")
    p.add_argument("--port", type=int, default=8081)
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--open-time", type=float, default=3.0)
    p.add_argument("--hold", type=float, default=25.0)
    p.add_argument("--stuck", action="store_true", help="la porte ne s'ouvre jamais")
    p.add_argument("--close-mode", choices=("auto", "commande"), default="auto",
                   help="commande : la porte ne redescend qu'après une impulsion de fermeture (K2)")
    p.add_argument("--close-time", type=float, default=3.0, help="durée de descente (s)")
    a = p.parse_args()
    token = os.environ.get("SPOT_DOOR_TOKEN", "")
    if len(token) < 16:
        raise SystemExit("Définir SPOT_DOOR_TOKEN (16 caractères minimum).")
    srv = serve(a.door_id, token, a.port,
                SimulatedDoor(a.open_time, a.hold, close_time_s=a.close_time, stuck=a.stuck,
                              close_mode=a.close_mode),
                host=a.host)
    print(f"Simulateur {a.door_id} sur http://{a.host}:{a.port}/api/v1  (Ctrl+C pour arrêter)")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        srv.shutdown()


if __name__ == "__main__":
    main()
